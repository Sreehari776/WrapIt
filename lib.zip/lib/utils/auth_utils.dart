import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:canteen_app/screens/sign_in_screen.dart';
import 'dart:developer' as developer;

class AuthUtils {
  static Future<void> logout(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
    } catch (e, st) {
      developer.log('Auth signOut error: $e', error: e, stackTrace: st);
    }

    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const SignInScreen()),
        (route) => false,
      );
    }

    try {
      await FirebaseFirestore.instance.terminate();
      await FirebaseFirestore.instance.clearPersistence();
      await FirebaseFirestore.instance.enableNetwork();
    } catch (e, st) {
      developer.log('Firestore cleanup failed (non-fatal): $e', error: e, stackTrace: st);
    }
  }
}
