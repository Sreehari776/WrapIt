import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:canteen_app/screens/sign_in_screen.dart';
import 'dart:developer' as developer;

class AuthUtils {
  /// Robust logout:
  /// 1) signs out the user (auth)
  /// 2) immediately navigates back to SignIn (so user is not stuck)
  /// 3) attempts Firestore cleanup (terminate/clear) in a best-effort way
  static Future<void> logout(BuildContext context) async {
    try {
      // 1) Sign out from Firebase Auth
      await FirebaseAuth.instance.signOut();
    } catch (e, st) {
      developer.log('Auth signOut error: $e', error: e, stackTrace: st);
      // still proceed to navigate back to login
    }

    // 2) Navigate right away so user is not stuck
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const SignInScreen()),
        (route) => false,
      );
    }

    // 3) Best-effort Firestore cleanup (do not block navigation)
    try {
      // terminate & clear persistence in a try/catch to avoid crashing
      await FirebaseFirestore.instance.terminate();
      await FirebaseFirestore.instance.clearPersistence();
      // re-enable network so next login works smoothly
      await FirebaseFirestore.instance.enableNetwork();
    } catch (e, st) {
      developer.log('Firestore cleanup failed (non-fatal): $e', error: e, stackTrace: st);
      // it's safe to ignore; we already navigated the user away
    }
  }
}
