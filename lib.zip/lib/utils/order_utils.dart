import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<bool> placeOrder({
  required String canteenId,
  required List<Map<String, dynamic>> items,
  required double total,
  required String paymentRef,
  required BuildContext context,
}) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please sign in')));
    return false;
  }

  final uid = user.uid;

  final canteenOrdersRef = FirebaseFirestore.instance
      .collection('canteens')
      .doc(canteenId)
      .collection('orders')
      .doc(); 

  final orderId = canteenOrdersRef.id;
  final orderData = {
    'orderId': orderId,
    'userId': uid,
    'items': items,
    'total': total,
    'status': 'Pending',
    'timestamp': FieldValue.serverTimestamp(),
    'paymentRef': paymentRef,
  };

  try {
    await canteenOrdersRef.set(orderData);

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('orders')
        .doc(orderId)
        .set(orderData);

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order placed successfully')));
    return true;
  } on FirebaseException catch (e) {
    final msg = 'FirebaseException (${e.code}): ${e.message}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order failed: ${e.code}')));
    debugPrint('placeOrder failed: $msg');
    return false;
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order failed: $e')));
    debugPrint('placeOrder general error: $e');
    return false;
  }
}
