import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class MenuMigrator extends StatelessWidget {
  final String canteenId;
  const MenuMigrator({super.key, required this.canteenId});

  Future<void> migrateMenu() async {
    final canteenRef = FirebaseFirestore.instance.collection('canteens').doc(canteenId);
    final canteenSnap = await canteenRef.get();

    if (!canteenSnap.exists) {
      debugPrint('Canteen not found: $canteenId');
      return;
    }

    final data = canteenSnap.data();
    if (data == null || data['menu'] == null) {
      debugPrint('No array menu found in $canteenId');
      return;
    }

    final List<dynamic> oldMenu = data['menu'];
    final menuCol = canteenRef.collection('menu');

    final batch = FirebaseFirestore.instance.batch();
    for (final item in oldMenu) {
      final id = (item['id'] ?? item['name']).toString().toLowerCase().replaceAll(' ', '_');
      final docRef = menuCol.doc(id);
      batch.set(docRef, {
        'name': item['name'],
        'category': item['category'] ?? 'general',
        'price': item['price'] ?? 0,
        'dailyStock': item['dailyStock'] ?? 20,
        'remainingToday': item['remainingToday'] ?? item['dailyStock'] ?? 20,
        'lowStockThreshold': item['lowStockThreshold'] ?? 5,
        'lastResetDate': DateTime.now().toIso8601String(),
      }, SetOptions(merge: true));
    }

    await batch.commit();
    debugPrint('✅ Menu migration complete for $canteenId');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Migrate Menu: $canteenId')),
      body: Center(
        child: ElevatedButton(
          onPressed: migrateMenu,
          child: const Text('Run Migration'),
        ),
      ),
    );
  }
}
