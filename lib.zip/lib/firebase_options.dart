
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;



class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCIMpJCex11RsaY-_Ys2XiuV7g6lhX5nTA',
    appId: '1:146967037981:web:0386cb640aaf6ef5a41ef4',
    messagingSenderId: '146967037981',
    projectId: 'wrapit-d3156',
    authDomain: 'wrapit-d3156.firebaseapp.com',
    storageBucket: 'wrapit-d3156.firebasestorage.app',
    measurementId: 'G-CJDV1XFQ61',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAczy9apQib0yUJmKKVV39M76D5NA6rBzQ',
    appId: '1:146967037981:android:f40ab2cc3462a348a41ef4',
    messagingSenderId: '146967037981',
    projectId: 'wrapit-d3156',
    storageBucket: 'wrapit-d3156.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCkEwQcFzGE-UiFt3q1-ytW_AIrKPfceOI',
    appId: '1:146967037981:ios:ff7e322729aac9dea41ef4',
    messagingSenderId: '146967037981',
    projectId: 'wrapit-d3156',
    storageBucket: 'wrapit-d3156.firebasestorage.app',
    iosBundleId: 'com.example.canteenApp',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCkEwQcFzGE-UiFt3q1-ytW_AIrKPfceOI',
    appId: '1:146967037981:ios:ff7e322729aac9dea41ef4',
    messagingSenderId: '146967037981',
    projectId: 'wrapit-d3156',
    storageBucket: 'wrapit-d3156.firebasestorage.app',
    iosBundleId: 'com.example.canteenApp',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyCIMpJCex11RsaY-_Ys2XiuV7g6lhX5nTA',
    appId: '1:146967037981:web:d34e29975ca0f9fba41ef4',
    messagingSenderId: '146967037981',
    projectId: 'wrapit-d3156',
    authDomain: 'wrapit-d3156.firebaseapp.com',
    storageBucket: 'wrapit-d3156.firebasestorage.app',
    measurementId: 'G-BQK7JMHQ56',
  );
}
