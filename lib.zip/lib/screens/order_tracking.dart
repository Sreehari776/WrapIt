import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class OrderTrackingScreen extends StatefulWidget {
  final DocumentSnapshot<Map<String, dynamic>>? orderDoc;
  final String? orderId;

  const OrderTrackingScreen({super.key, this.orderDoc, this.orderId})
      : assert(orderDoc != null || orderId != null, 'Provide orderDoc or orderId');

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  late final String docId;
  bool _updating = false;
  bool _locating = false;
  bool _autoScanned = false;
  String? _locatedPath;
  final List<String> _statuses = ['placed', 'confirmed', 'preparing', 'completed', 'cancelled'];

  @override
  void initState() {
    super.initState();
    docId = widget.orderDoc?.id ?? widget.orderId!;
    debugPrint('🔎 OrderTracking init for docId=$docId');
  }

  Future<void> _updateStatus(String newStatus) async {
    setState(() => _updating = true);
    try {
      DocumentReference<Map<String, dynamic>> targetRef;
      if (_locatedPath != null && _locatedPath!.isNotEmpty) {
        targetRef = FirebaseFirestore.instance.doc(_locatedPath!).withConverter(
          fromFirestore: (s, _) => s.data() ?? <String, dynamic>{},
          toFirestore: (m, _) => m,
        );
      } else {
        targetRef = FirebaseFirestore.instance.collection('orders').doc(docId);
      }

      final adminUid = FirebaseAuth.instance.currentUser?.uid;
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(targetRef);
        if (!snap.exists) throw FirebaseException(plugin: 'firebase_firestore', code: 'not-found', message: 'Order doc not found at ${targetRef.path}');
        tx.update(targetRef, {
          'status': newStatus,
          'lastUpdatedAt': FieldValue.serverTimestamp(),
          if (adminUid != null) 'lastUpdatedBy': adminUid,
        });
      });

      if (!mounted) return;
      setState(() => _updating = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order status updated to "$newStatus"')));
      debugPrint('✅ Updated order $docId -> $newStatus at ${targetRef.path}');
    } on FirebaseException catch (fe) {
      setState(() => _updating = false);
      debugPrint('FirebaseException updating order: ${fe.code} ${fe.message}');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: ${fe.message}')));
    } catch (e, st) {
      setState(() => _updating = false);
      debugPrint('Error updating order: $e\n$st');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
    }
  }

  DocumentReference<Map<String, dynamic>> _defaultDocRef() {
    final canteenIdFromDoc = widget.orderDoc?.data()?['canteenId'] as String?;
    if (canteenIdFromDoc != null && canteenIdFromDoc.isNotEmpty) {
      final p = FirebaseFirestore.instance
          .collection('canteens')
          .doc(canteenIdFromDoc)
          .collection('orders')
          .doc(docId);
      debugPrint('ℹ️ Using nested path: ${p.path}');
      return p;
    }
    final top = FirebaseFirestore.instance.collection('orders').doc(docId);
    debugPrint('ℹ️ Falling back to top-level path: ${top.path}');
    return top;
  }

  Future<void> _locateOrderByScanningCanteens() async {
    setState(() {
      _locating = true;
      _locatedPath = null;
    });

    try {
      final canteensSnap = await FirebaseFirestore.instance.collection('canteens').get();
      debugPrint('🗂️ Found ${canteensSnap.docs.length} canteens — scanning for order $docId');
      for (final c in canteensSnap.docs) {
        final candidate = FirebaseFirestore.instance.collection('canteens').doc(c.id).collection('orders').doc(docId);
        final s = await candidate.get();
        if (s.exists) {
          if (!mounted) return;
          setState(() => _locatedPath = candidate.path);
          debugPrint('🎯 Order located at: ${candidate.path}');
          break;
        }
      }
      if (_locatedPath == null) {
        final top = FirebaseFirestore.instance.collection('orders').doc(docId);
        final topSnap = await top.get();
        if (topSnap.exists) {
          if (!mounted) return;
          setState(() => _locatedPath = top.path);
          debugPrint('🎯 Order located at top-level: ${top.path}');
        }
      }
    } catch (e, st) {
      debugPrint('Error scanning canteens: $e\n$st');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Locate failed: $e')));
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final DocumentReference<Map<String, dynamic>> docRef;
    if (_locatedPath != null && _locatedPath!.isNotEmpty) {
      debugPrint('🔁 Using locatedPath for listening: $_locatedPath');
      docRef = FirebaseFirestore.instance.doc(_locatedPath!).withConverter(
        fromFirestore: (snap, _) => snap.data() ?? <String, dynamic>{},
        toFirestore: (m, _) => m,
      );
    } else {
      docRef = _defaultDocRef();
    }

    debugPrint('📦 Listening to docId=$docId at path=${docRef.path}');

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: docRef.snapshots(),
      builder: (context, snap) {
        debugPrint('Stream snapshot state: connectionState=${snap.connectionState}, hasData=${snap.hasData}, error=${snap.error}');

        if (snap.hasError) {
          final err = snap.error;
          debugPrint('Stream error: $err');
          return Scaffold(
            appBar: AppBar(title: const Text('Order Tracking')),
            body: Center(child: Text('Error loading order: $err')),
          );
        }

        if (snap.connectionState == ConnectionState.waiting) {
          return Scaffold(
            appBar: AppBar(title: const Text('Order Tracking')),
            body: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 12),
                Text('Waiting for Firestore snapshot at:\n${docRef.path}', textAlign: TextAlign.center),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _locating ? null : _locateOrderByScanningCanteens,
                  child: _locating ? const Text('Scanning...') : const Text('Locate order (scan canteens)'),
                ),
                const SizedBox(height: 6),
                if (_locatedPath != null) Text('Located at: $_locatedPath'),
              ]),
            ),
          );
        }

        if (!snap.hasData || !snap.data!.exists) {
          if (!_autoScanned && !_locating) {
            _autoScanned = true;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _locateOrderByScanningCanteens();
            });
          }

          return Scaffold(
            appBar: AppBar(title: const Text('Order Tracking')),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(18.0),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.search_off, size: 48, color: Colors.grey),
                  const SizedBox(height: 12),
                  Text('Order not found at path:\n${docRef.path}', textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _locating ? null : _locateOrderByScanningCanteens,
                    child: _locating ? const Text('Scanning...') : const Text('Locate order (scan canteens)'),
                  ),
                  const SizedBox(height: 6),
                  if (_locatedPath != null) Text('Located at: $_locatedPath'),
                  const SizedBox(height: 8),
                  const Text('Tip: check Firestore console to confirm the document and ensure rules allow reads.'),
                ]),
              ),
            ),
          );
        }

        // Document exists — render details
        final data = snap.data!.data() ?? <String, dynamic>{};
        final orderIdString = (data['orderIdString'] as String?) ?? snap.data!.id;
        final canteenId = (data['canteenId'] as String?) ?? '-';
        final userId = (data['userId'] as String?) ?? '-';
        final total = (data['total'] as num?)?.toDouble() ?? 0.0;
        final paymentRef = (data['payment']?['reference'] as String?) ?? '-';
        final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
        final status = (data['status'] as String?) ?? 'placed';
        final items = (data['items'] as List<dynamic>?) ?? [];
        final lastUpdatedBy = (data['lastUpdatedBy'] as String?) ?? '-';
        final lastUpdatedAt = (data['lastUpdatedAt'] as Timestamp?)?.toDate();

        return Scaffold(
          appBar: AppBar(
            title: Text(orderIdString),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: () => setState(() {}),
              )
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(14.0),
            child: ListView(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Canteen: $canteenId', style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (createdAt != null) Text(DateFormat('dd MMM, hh:mm a').format(createdAt)),
                ]),
                const SizedBox(height: 8),
                Text('User: $userId'),
                const SizedBox(height: 8),
                Text('Payment Ref: $paymentRef'),
                const SizedBox(height: 8),
                Text('Total: ₹${total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(children: [const Text('Status: '), Chip(label: Text(status.toUpperCase()))]),
                if (lastUpdatedBy != '-') ...[
                  const SizedBox(height: 8),
                  Text('Last updated by: $lastUpdatedBy'),
                  if (lastUpdatedAt != null) Text('at ${DateFormat('dd MMM, hh:mm a').format(lastUpdatedAt)}'),
                ],
                const Divider(height: 28),
                const Text('Items', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                ...items.map((it) {
                  final m = Map<String, dynamic>.from(it as Map);
                  final price = (m['price'] as num?)?.toDouble() ?? 0.0;
                  final qty = (m['qty'] as num?)?.toInt() ?? 0;
                  return ListTile(
                    dense: true,
                    title: Text(m['name'] ?? ''),
                    subtitle: Text('₹${price.toStringAsFixed(2)} × $qty = ₹${(price * qty).toStringAsFixed(2)}'),
                  );
                }),
                const SizedBox(height: 20),
                const Text('Update status', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                if (_updating)
                  const Center(child: CircularProgressIndicator())
                else
                  Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    DropdownButtonFormField<String>(
                      value: status,
                      decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Status'),
                      items: _statuses.map((s) => DropdownMenuItem(value: s, child: Text(s.toUpperCase()))).toList(),
                      onChanged: (val) {
                        if (val != null && val != status) _updateStatus(val);
                      },
                    ),
                    const SizedBox(height: 10),
                    Wrap(spacing: 10, children: [
                      ElevatedButton.icon(
                        onPressed: status != 'confirmed' ? () => _updateStatus('confirmed') : null,
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Confirm'),
                      ),
                      ElevatedButton.icon(
                        onPressed: status != 'preparing' ? () => _updateStatus('preparing') : null,
                        icon: const Icon(Icons.local_dining_outlined),
                        label: const Text('Preparing'),
                      ),
                      ElevatedButton.icon(
                        onPressed: status != 'completed' ? () => _updateStatus('completed') : null,
                        icon: const Icon(Icons.done_all),
                        label: const Text('Complete'),
                      ),
                      ElevatedButton.icon(
                        onPressed: status != 'cancelled' ? () => _updateStatus('cancelled') : null,
                        icon: const Icon(Icons.cancel_outlined),
                        label: const Text('Cancel'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      ),
                      ElevatedButton(
  onPressed: () async {
    final id = docId; 
    try {
      await FirebaseFirestore.instance.collection('orders').doc(id).update({
        'status': 'debug_test',
        'lastUpdatedAt': FieldValue.serverTimestamp(),
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Manual update OK')));
      debugPrint('Manual update OK for $id');
    } catch (e, st) {
      debugPrint('Manual update failed: $e\n$st');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Manual update failed: $e')));
    }
  },
  child: const Text('DEBUG: manual update'),
),

                    ]),
                  ]),
              ],
            ),
          ),
        );
      },
    );
  }
}
