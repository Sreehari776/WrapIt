// lib/screens/cart_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:intl/intl.dart';

class CartScreen extends StatefulWidget {
  final String canteenId;
  final String canteenName;

  const CartScreen({super.key, required this.canteenId, required this.canteenName});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final TextEditingController _paymentRefController = TextEditingController();
  bool _placing = false;
  DateTime? _prebookTime;

  Stream<QuerySnapshot<Map<String, dynamic>>> _cartStream(String uid) {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('cart')
        .snapshots();
  }

  double _computeTotal(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    double total = 0.0;
    for (var d in docs) {
      final data = d.data();
      final price = (data['price'] ?? 0);
      final qtyRaw = data['quantity'] ?? data['qty'] ?? data['count'] ?? 1;
      final p = (price is num) ? price.toDouble() : double.tryParse('$price') ?? 0.0;
      final q = (qtyRaw is num) ? qtyRaw.toInt() : (int.tryParse('$qtyRaw') ?? 1);
      total += p * q;
    }
    return total;
  }

  List<Map<String, dynamic>> _buildItemsPayloadFromDocs(
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    return docs.map((d) {
      final m = d.data();
      final qty = (m['quantity'] ?? 1) is num
          ? (m['quantity'] ?? 1).toInt()
          : int.tryParse('${m['quantity']}') ?? 1;
      return {
        'menuId': m['itemId'] ?? m['id'] ?? d.id,
        'name': m['name'] ?? '',
        'qty': qty,
        'price': m['price'] ?? 0,
      };
    }).toList();
  }

  Future<void> _clearCart(String uid) async {
    final cartRef = FirebaseFirestore.instance.collection('users').doc(uid).collection('cart');
    final cartItems = await cartRef.get();
    final batch = FirebaseFirestore.instance.batch();
    for (var doc in cartItems.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  Future<void> _incrementCartItem(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    await doc.reference.update({'quantity': FieldValue.increment(1)});
  }

  Future<void> _decrementCartItem(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final qty = (data['quantity'] ?? 1) is num
        ? (data['quantity'] ?? 1).toInt()
        : int.tryParse('${data['quantity']}') ?? 1;
    if (qty <= 1) {
      await doc.reference.delete();
    } else {
      await doc.reference.update({'quantity': FieldValue.increment(-1)});
    }
  }

  String _prefixForCanteen(String canteenName, String canteenId) {
    final name = canteenName.toLowerCase();
    if (name.contains('old')) return 'O';
    if (name.contains('south')) return 'S';
    if (name.contains('north')) return 'N';
    final sanitized = canteenName.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');
    final s = sanitized.isEmpty ? canteenId : sanitized;
    return s.length <= 3 ? s.toUpperCase() : s.substring(0, 3).toUpperCase();
  }

  Future<String> _generateOrderNumber(String canteenId, String canteenName) async {
    final ref = FirebaseFirestore.instance.collection('canteens').doc(canteenId);
    int seq = 0;
    final prefix = _prefixForCanteen(canteenName, canteenId);
    try {
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final doc = await tx.get(ref);
        final current = doc.data()?['lastOrderSeq'];
        seq = (current == null ? 1 : (current as int) + 1);
        tx.set(ref, {'lastOrderSeq': seq}, SetOptions(merge: true));
      });
    } catch (e) {
      seq = DateTime.now().millisecondsSinceEpoch % 10000;
    }
    return 'ORD-$prefix-${seq.toString().padLeft(4, '0')}';
  }

  /// Transactional order placement that supports both menu subcollection documents
  /// and menu array stored on the canteen document.
  Future<bool> _placeOrderTransaction(
      BuildContext context, String canteenId, String userId, Map<String, dynamic> orderData) async {
    final db = FirebaseFirestore.instance;
    final canteenRef = db.collection('canteens').doc(canteenId);
    final canteenOrders = canteenRef.collection('orders');
    final userOrders = db.collection('users').doc(userId).collection('orders');

    try {
      await db.runTransaction((tx) async {
        final List<Map<String, dynamic>> items =
            List<Map<String, dynamic>>.from(orderData['items'] ?? []);

        // We'll collect updates to parent menu array if needed
        bool parentMenuNeedsUpdate = false;
        List<dynamic> updatedParentMenu = [];

        // If parent menu array is needed, read it once
        DocumentSnapshot<Map<String, dynamic>>? parentDoc;
        List<dynamic>? parentMenuArray;

        // Prepare to store resolved menuDoc updates (for subcollection items)
        final List<Map<String, dynamic>> subcollectionUpdates = [];

        for (final it in items) {
          final menuId = (it['menuId'] ?? it['id'] ?? it['menu_id'] ?? it['menuId']).toString();
          final qty = (it['qty'] ?? it['quantity'] ?? 1) is num ? (it['qty'] ?? it['quantity'] ?? 1) as int : int.tryParse('${it['qty'] ?? it['quantity'] ?? 1}') ?? 1;

          final menuRef = canteenRef.collection('menu').doc(menuId);
          final menuSnap = await tx.get(menuRef);

          if (menuSnap.exists) {
            // Subcollection item: check stock and plan update
            final data = menuSnap.data() ?? {};
            final stockVal = data['remainingToday'] ?? data['remaining'] ?? data['stock'] ?? data['dailyStock'] ?? 0;
            final stock = (stockVal is num) ? stockVal.toInt() : int.tryParse('$stockVal') ?? 0;
            if (stock < qty) {
              throw Exception('Not enough stock for ${data['name'] ?? menuId}');
            }
            subcollectionUpdates.add({'ref': menuRef, 'newStock': stock - qty, 'lowThreshold': data['lowThreshold'] ?? 5, 'name': data['name'] ?? menuId});
          } else {
            // Not in subcollection -> use parent doc's menu array
            parentDoc ??= await tx.get(canteenRef);
            parentMenuArray ??= List<dynamic>.from(parentDoc.data()?['menu'] ?? []);
            // find item by id or matching name
            int foundIndex = -1;
            Map<String, dynamic>? foundMap;
            for (var i = 0; i < parentMenuArray.length; i++) {
              final element = Map<String, dynamic>.from(parentMenuArray[i] as Map);
              final elId = (element['id'] ?? element['menuId'] ?? element['itemId'])?.toString() ?? '';
              final elName = (element['name'] ?? element['Name'])?.toString() ?? '';
              if (elId == menuId || elName == it['name']) {
                foundIndex = i;
                foundMap = element;
                break;
              }
            }
            if (foundIndex == -1 || foundMap == null) {
              throw Exception('Menu item not found for ${it['name'] ?? menuId}');
            }

            final stockVal = foundMap['remainingToday'] ?? foundMap['remaining'] ?? foundMap['stock'] ?? foundMap['dailyStock'] ?? 0;
            final stock = (stockVal is num) ? stockVal.toInt() : int.tryParse('$stockVal') ?? 0;
            if (stock < qty) {
              throw Exception('Not enough stock for ${foundMap['name'] ?? menuId}');
            }

            // Prepare updated element (mutate copy)
            final updated = Map<String, dynamic>.from(foundMap);
            // determine which field to write back (prefer remainingToday, then remaining, then stock)
            if (foundMap.containsKey('remainingToday')) {
              updated['remainingToday'] = stock - qty;
            } else if (foundMap.containsKey('remaining')) {
              updated['remaining'] = stock - qty;
            } else if (foundMap.containsKey('stock')) {
              updated['stock'] = stock - qty;
            } else if (foundMap.containsKey('dailyStock')) {
              updated['dailyStock'] = stock - qty;
              updated['remainingToday'] = stock - qty;
            } else {
              // fallback: set remainingToday
              updated['remainingToday'] = stock - qty;
            }
            // apply in the local copy of parentMenuArray
            parentMenuArray[foundIndex] = updated;
            parentMenuNeedsUpdate = true;
          }
        } // end items loop

        // Write order doc to canteen orders (id provided by caller)
        final orderId = orderData['orderId'];
        final orderDocRef = canteenOrders.doc(orderId);
        tx.set(orderDocRef, {
          ...orderData,
          'status': 'placed',
          'placedAt': FieldValue.serverTimestamp(),
        });

        // Commit subcollection updates
        for (final upd in subcollectionUpdates) {
          final ref = upd['ref'] as DocumentReference;
          final newStock = upd['newStock'] as int;
          tx.update(ref, {'remainingToday': newStock, 'stock': newStock});
          final lowThreshold = upd['lowThreshold'] as int? ?? 5;
          if (newStock <= lowThreshold) {
            final notifRef = canteenRef.collection('meta').doc('notifications').collection('items').doc();
            tx.set(notifRef, {
              'menuId': ref.id,
              'itemName': upd['name'],
              'stock': newStock,
              'message': '${upd['name']} low: $newStock left',
              'createdAt': FieldValue.serverTimestamp(),
              'read': false,
            });
          }
        }

        // If parent menu array changed, write updated array back atomically
        if (parentMenuNeedsUpdate && parentMenuArray != null) {
          tx.update(canteenRef, {'menu': parentMenuArray});
          // Optionally: generate notifications for low stock from parent array
          for (final element in parentMenuArray) {
            final el = Map<String, dynamic>.from(element as Map);
            final newStockVal = el['remainingToday'] ?? el['remaining'] ?? el['stock'] ?? 0;
            final newStock = (newStockVal is num) ? newStockVal.toInt() : int.tryParse('$newStockVal') ?? 0;
            final low = (el['lowThreshold'] ?? 5) is num ? (el['lowThreshold'] ?? 5) as int : int.tryParse('${el['lowThreshold'] ?? 5}') ?? 5;
            if (newStock <= low) {
              final notifRef = canteenRef.collection('meta').doc('notifications').collection('items').doc();
              tx.set(notifRef, {
                'menuId': el['id'] ?? el['menuId'] ?? '',
                'itemName': el['name'] ?? '',
                'stock': newStock,
                'message': '${el['name']} low: $newStock left',
                'createdAt': FieldValue.serverTimestamp(),
                'read': false,
              });
            }
          }
        }

        // Write to user orders
        tx.set(userOrders.doc(orderId), {
          ...orderData,
          'status': 'placed',
          'placedAt': FieldValue.serverTimestamp(),
        });
      });

      return true;
    } catch (e) {
      debugPrint('Transaction failed: $e');
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Order failed: $e')));
      }
      return false;
    }
  }

  Future<void> _confirmOrder() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Please sign in')));
      return;
    }

    final uid = user.uid;
    final cartSnap = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('cart')
        .get();
    final docs = cartSnap.docs;

    if (docs.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Cart is empty')));
      return;
    }

    final items = _buildItemsPayloadFromDocs(docs);
    final total = _computeTotal(docs);
    final paymentRef = _paymentRefController.text.trim();
    if (paymentRef.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Enter payment reference')));
      return;
    }

    setState(() => _placing = true);
    try {
      final orderId = FirebaseFirestore.instance
          .collection('canteens')
          .doc(widget.canteenId)
          .collection('orders')
          .doc()
          .id;
      final orderNumber =
          await _generateOrderNumber(widget.canteenId, widget.canteenName);

      final orderData = {
        'orderId': orderId,
        'orderNumber': orderNumber,
        'userId': uid,
        'canteen': widget.canteenName,
        'items': items,
        'total': total,
        'paymentRefId': paymentRef,
      };

      final success = await _placeOrderTransaction(
          context, widget.canteenId, uid, orderData);

      if (success) {
        await _clearCart(uid);
        _paymentRefController.clear();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order placed successfully!')),
        );
      }
    } finally {
      setState(() => _placing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(
          body: Center(child: Text('Please sign in to view cart')));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.canteenName} - Cart'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _cartStream(user.uid),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          final total = _computeTotal(docs);

          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Expanded(
                  child: docs.isEmpty
                      ? const Center(child: Text('Cart is empty'))
                      : ListView.builder(
                          itemCount: docs.length,
                          itemBuilder: (ctx, i) {
                            final doc = docs[i];
                            final d = doc.data();
                            final name = d['name'] ?? 'Item';
                            final price = d['price'] ?? 0;
                            final qty = (d['quantity'] ?? 1) is num
                                ? (d['quantity'] ?? 1).toInt()
                                : int.tryParse('${d['quantity']}') ?? 1;
                            return Card(
                              margin: const EdgeInsets.symmetric(vertical: 6),
                              child: ListTile(
                                title: Text(name),
                                subtitle: Text('Qty: $qty'),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                        icon: const Icon(
                                            Icons.remove_circle_outline),
                                        onPressed: () =>
                                            _decrementCartItem(doc)),
                                    Text('$qty'),
                                    IconButton(
                                        icon: const Icon(
                                            Icons.add_circle_outline),
                                        onPressed: () =>
                                            _incrementCartItem(doc)),
                                    const SizedBox(width: 8),
                                    Text('₹$price'),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _paymentRefController,
                  decoration: InputDecoration(
                    labelText: 'Payment Reference ID',
                    border:
                        OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                QrImageView(
                  data:
                      'upi://pay?pa=sreeharim776@oksbi&pn=WrapIt&am=${total.toStringAsFixed(2)}&tn=Order',
                  size: 140.0,
                ),
                const SizedBox(height: 16),
                _placing
                    ? const CircularProgressIndicator()
                    : ElevatedButton.icon(
                        onPressed: _confirmOrder,
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Confirm Order'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          foregroundColor: Colors.white,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
              ],
            ),
          );
        },
      ),
    );
  }
}
