import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:intl/intl.dart';

class CartScreen extends StatefulWidget {
  final String canteenId;
  final String canteenName;

  const CartScreen({super.key, required this.canteenId, required this.canteenName});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final TextEditingController _paymentRefController = TextEditingController();
  bool _placing = false;
  DateTime? _prebookTime;
  TimeOfDay? _canteenOpens;
  TimeOfDay? _canteenCloses;
  bool _canteenHoursLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadCanteenHours();
  }

  @override
  void dispose() {
    _paymentRefController.dispose();
    super.dispose();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> _cartStream(String uid) {
    return FirebaseFirestore.instance.collection('users').doc(uid).collection('cart').snapshots();
  }

  double _computeTotal(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    double total = 0.0;
    for (var d in docs) {
      final data = d.data();
      final price = (data['price'] ?? 0);
      final qtyRaw = data['quantity'] ?? data['qty'] ?? data['count'] ?? 1;
      final p = (price is num) ? price.toDouble() : double.tryParse('$price') ?? 0.0;
      final q = (qtyRaw is num) ? qtyRaw.toInt() : (int.tryParse('$qtyRaw') ?? 1);
      total += p * q;
    }
    return total;
  }

  List<Map<String, dynamic>> _buildItemsPayloadFromDocs(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    return docs.map((d) {
      final m = d.data();
      final qty = (m['quantity'] ?? 1) is num ? (m['quantity'] ?? 1).toInt() : int.tryParse('${m['quantity']}') ?? 1;
      return {
        'menuId': m['itemId'] ?? m['id'] ?? d.id,
        'name': m['name'] ?? '',
        'qty': qty,
        'price': m['price'] ?? 0,
      };
    }).toList();
  }

  Future<void> _clearCart(String uid) async {
    final cartRef = FirebaseFirestore.instance.collection('users').doc(uid).collection('cart');
    final cartItems = await cartRef.get();
    final batch = FirebaseFirestore.instance.batch();
    for (var doc in cartItems.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  Future<void> _incrementCartItem(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    await doc.reference.update({'quantity': FieldValue.increment(1)});
  }

  Future<void> _decrementCartItem(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final qty = (data['quantity'] ?? 1) is num ? (data['quantity'] ?? 1).toInt() : int.tryParse('${data['quantity']}') ?? 1;
    if (qty <= 1) {
      await doc.reference.delete();
    } else {
      await doc.reference.update({'quantity': FieldValue.increment(-1)});
    }
  }

  Future<void> _loadCanteenHours() async {
    if (_canteenHoursLoaded) return;
    try {
      final doc = await FirebaseFirestore.instance.collection('canteens').doc(widget.canteenId).get();
      final data = doc.data() ?? {};
      final opens = (data['opensAt'] ?? data['opens'] ?? '8:00').toString();
      final closes = (data['closesAt'] ?? data['closes'] ?? '17:00').toString();

      TimeOfDay? parse(String s) {
        final parts = s.split(RegExp(r'[:.]'));
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0].trim()) ?? 0;
          final m = int.tryParse(parts[1].trim()) ?? 0;
          return TimeOfDay(hour: h, minute: m);
        }
        return null;
      }

      _canteenOpens = parse(opens) ?? TimeOfDay(hour: 8, minute: 0);
      _canteenCloses = parse(closes) ?? TimeOfDay(hour: 17, minute: 0);
    } catch (e) {
      _canteenOpens = TimeOfDay(hour: 8, minute: 0);
      _canteenCloses = TimeOfDay(hour: 17, minute: 0);
    } finally {
      _canteenHoursLoaded = true;
      if (mounted) setState(() {});
    }
  }

  DateTime _combineDateAndTime(DateTime date, TimeOfDay tod) {
    return DateTime(date.year, date.month, date.day, tod.hour, tod.minute);
  }

  String _prefixForCanteen(String canteenName, String canteenId) {
    final name = canteenName.toLowerCase();
    if (name.contains('old')) return 'O';
    if (name.contains('south')) return 'S';
    if (name.contains('north')) return 'N';
    final sanitized = canteenName.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');
    final s = sanitized.isEmpty ? canteenId : sanitized;
    return s.length <= 3 ? s.toUpperCase() : s.substring(0, 3).toUpperCase();
  }

  Future<String> _generateOrderNumber(String canteenId, String canteenName) async {
    final ref = FirebaseFirestore.instance.collection('canteens').doc(canteenId);
    int seq = 0;
    final prefix = _prefixForCanteen(canteenName, canteenId);
    try {
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final doc = await tx.get(ref);
        final current = doc.data()?['lastOrderSeq'];
        seq = (current == null ? 1 : (current as int) + 1);
        tx.set(ref, {'lastOrderSeq': seq}, SetOptions(merge: true));
      });
    } catch (e) {
      seq = DateTime.now().millisecondsSinceEpoch % 10000;
    }
    return 'ORD-$prefix-${seq.toString().padLeft(4, '0')}';
  }

  Future<bool> _placeOrderTransaction(
  BuildContext context,
  String canteenId,
  String userId,
  Map<String, dynamic> orderData, {
  bool updateStockAndNotify = false, // set true to enable stock decrement + admin alerts
}) async {
  final db = FirebaseFirestore.instance;
  final canteenRef = db.collection('canteens').doc(canteenId);
  final canteenOrders = canteenRef.collection('orders');
  final userOrders = db.collection('users').doc(userId).collection('orders');

  if (!orderData.containsKey('orderId')) {
    debugPrint('ORDER: missing orderId in orderData');
    return false;
  }

  orderData['canteenId'] = canteenId;
  final orderId = orderData['orderId'];

  try {
    debugPrint('ORDER TX: starting transaction for $orderId (canteen=$canteenId, user=$userId)');
    // collect alerts if stock falls below threshold (will be sent after commit)
    final List<Map<String, dynamic>> lowStockAlerts = [];

    await db.runTransaction((tx) async {
      // Build order payload with timestamps
      final dataToWrite = {
        ...orderData,
        'status': 'placed',
        'placedAt': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
      };

      if (!updateStockAndNotify) {
        // Simple path: only write orders (preserves existing behaviour)
        tx.set(canteenOrders.doc(orderId), dataToWrite);
        tx.set(userOrders.doc(orderId), dataToWrite);
        return;
      }

      // Enhanced path: we will adjust menu stock inside the same transaction
      final canteenSnap = await tx.get(canteenRef);
      if (!canteenSnap.exists) {
        throw Exception('Canteen document not found');
      }

      final canteenData = canteenSnap.data() ?? {};
      final rawMenu = canteenData['menu'];

      // Normalize menu: accept List<Map> or Map-of-maps; produce mutable List<Map<String,dynamic>>
      final List<Map<String, dynamic>> menuList = <Map<String, dynamic>>[];
      if (rawMenu is List) {
        for (final e in rawMenu) {
          if (e is Map) menuList.add(Map<String, dynamic>.from(e as Map));
        }
      } else if (rawMenu is Map) {
        for (final key in rawMenu.keys) {
          final val = rawMenu[key];
          if (val is Map) {
            final m = Map<String, dynamic>.from(val);
            if (!m.containsKey('id')) m['id'] = key;
            menuList.add(m);
          }
        }
      } else {
        // no menu or unexpected format: treat as empty
        throw Exception('Canteen menu missing or invalid format');
      }

      final List<dynamic> orderedItems = (orderData['items'] as List<dynamic>?) ?? [];
      if (orderedItems.isEmpty) throw Exception('No items to order');

      // For each ordered item, find matching menu item and decrement stock
      for (final oi in orderedItems) {
        final o = (oi is Map) ? Map<String, dynamic>.from(oi as Map) : <String, dynamic>{};
        final menuId = (o['menuId'] ?? o['itemId'] ?? o['id'] ?? '').toString();
        final qty = (o['qty'] is num) ? (o['qty'] as num).toInt() : int.tryParse('${o['qty']}') ?? 1;

        final idx = menuList.indexWhere((m) {
          final mid = (m['id'] ?? m['itemId'] ?? '').toString();
          final mname = (m['name'] ?? '').toString();
          return (mid.isNotEmpty && mid == menuId) || (mname.isNotEmpty && mname == (o['name'] ?? ''));
        });

        if (idx == -1) {
          throw Exception('Menu item not found for ordered item: $menuId / ${o['name']}');
        }

        final menuItem = Map<String, dynamic>.from(menuList[idx]);

        // Interpret stock and threshold robustly
        final rawStock = menuItem['stock'];
        final currentStock = (rawStock is num) ? rawStock.toInt() : int.tryParse('$rawStock') ?? 999999;
        final newStock = currentStock - qty;

        if (newStock < 0) {
          throw Exception('Insufficient stock for ${menuItem['name'] ?? menuId}');
        }

        menuItem['stock'] = newStock;
        // Optional: mark outOfStock boolean when stock == 0
        if (newStock == 0) menuItem['outOfStock'] = true;
        else menuItem.remove('outOfStock');

        final rawThreshold = menuItem['threshold'];
        final threshold = (rawThreshold is num) ? rawThreshold.toInt() : int.tryParse('$rawThreshold') ?? -1;
        if (threshold >= 0 && newStock <= threshold) {
          lowStockAlerts.add({
            'menuId': menuItem['id'] ?? menuId,
            'name': menuItem['name'] ?? o['name'] ?? '',
            'stock': newStock,
            'threshold': threshold,
          });
        }

        // save back into menuList
        menuList[idx] = menuItem;
      }

      // All checks passed — write updated menu and the order docs inside transaction
      tx.update(canteenRef, {'menu': menuList});
      tx.set(canteenOrders.doc(orderId), dataToWrite);
      tx.set(userOrders.doc(orderId), dataToWrite);
    }); // end transaction

    debugPrint('ORDER TX: transaction committed for $orderId — verifying...');

    // Post-transaction verification (same as your previous logic)
    final canteenOrderSnap = await canteenOrders.doc(orderId).get();
    final userOrderSnap = await userOrders.doc(orderId).get();
    debugPrint('ORDER VERIFY: canteenOrder.exists=${canteenOrderSnap.exists}, userOrder.exists=${userOrderSnap.exists}');

    if (!(canteenOrderSnap.exists && userOrderSnap.exists)) {
      // Attempt fallback writes similar to your previous function
      if (!canteenOrderSnap.exists) {
        const int maxRetries = 3;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
          try {
            await canteenOrders.doc(orderId).set({
              ...orderData,
              'status': 'placed',
              'placedAt': FieldValue.serverTimestamp(),
              'createdAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
            final check = await canteenOrders.doc(orderId).get();
            if (check.exists) {
              final ucheck = await userOrders.doc(orderId).get();
              if (ucheck.exists) return true;
            }
          } catch (e, st) {
            debugPrint('ORDER FALLBACK ERROR (attempt $attempt): $e\n$st');
          }
          await Future.delayed(Duration(milliseconds: 400 * attempt));
        }
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Order placed locally but admin view may not show it. Check logs.')));
        }
        return false;
      }

      if (!userOrderSnap.exists) {
        try {
          await userOrders.doc(orderId).set({
            ...orderData,
            'status': 'placed',
            'placedAt': FieldValue.serverTimestamp(),
            'createdAt': FieldValue.serverTimestamp(),
          });
          return true;
        } catch (e, st) {
          debugPrint('ORDER FIX USER ERROR: $e\n$st');
          return false;
        }
      }
    }

    // If we reach here and there are low-stock alerts, create notification docs for admins
    if (updateStockAndNotify && lowStockAlerts.isNotEmpty) {
      try {
        final adminQuery = await db
            .collection('users')
            .where('canteenId', isEqualTo: canteenId)
            .where('role', isEqualTo: 'admin')
            .get();

        for (final adminDoc in adminQuery.docs) {
          final adminUid = adminDoc.id;
          final notifRef = db.collection('users').doc(adminUid).collection('notifications').doc();

          final bodyLines = lowStockAlerts.map((a) => '${a['name']} → ${a['stock']} left (threshold ${a['threshold']})').join('\n');

          await notifRef.set({
            'title': 'Low stock alert',
            'body': bodyLines,
            'createdAt': FieldValue.serverTimestamp(),
            'read': false,
            'orderId': orderId,
            'canteenId': canteenId,
          });
        }
      } catch (e, st) {
        debugPrint('Failed to send low-stock notifications: $e\n$st');
      }
    }

    debugPrint('ORDER SUCCESS: placed $orderId');
    return true;
  } catch (e, st) {
    debugPrint('ORDER TX FAILED: $e\n$st');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order failed: $e')));
    }
    return false;
  }
}

  Future<void> _confirmOrder() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please sign in')));
      return;
    }

    final uid = user.uid;
    final cartSnap = await FirebaseFirestore.instance.collection('users').doc(uid).collection('cart').get();
    final docs = cartSnap.docs;

    if (docs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cart is empty')));
      return;
    }

    final items = _buildItemsPayloadFromDocs(docs);
    final total = _computeTotal(docs);
    final paymentRef = _paymentRefController.text.trim();
    if (paymentRef.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter payment reference')));
      return;
    }

    if (_prebookTime != null) {
      final minAllowed = DateTime.now().add(const Duration(minutes: 5));
      if (_prebookTime!.isBefore(minAllowed)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Prebook time must be at least 5 minutes from now')),
        );
        return;
      }
    }

    setState(() => _placing = true);
    try {
      final orderId = FirebaseFirestore.instance.collection('canteens').doc(widget.canteenId).collection('orders').doc().id;
      final orderNumber = await _generateOrderNumber(widget.canteenId, widget.canteenName);

      final orderData = {
        'orderId': orderId,
        'orderNumber': orderNumber,
        'userId': uid,
        'canteen': widget.canteenName,
        'items': items,
        'total': total,
        'paymentRefId': paymentRef,
        if (_prebookTime != null) 'prebookAt': _prebookTime!.toIso8601String(),
      };

      final success = await _placeOrderTransaction(context, widget.canteenId, uid, orderData);

      if (success) {
        await _clearCart(uid);
        _paymentRefController.clear();
        _prebookTime = null;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order placed successfully!')));
      }
    } finally {
      setState(() => _placing = false);
    }
  }

  Widget _buildEmptyCart() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.shopping_cart_outlined, size: 72, color: Colors.teal.shade200),
          const SizedBox(height: 12),
          Text('Your cart is empty', style: TextStyle(fontSize: 18, color: Colors.black54)),
          const SizedBox(height: 8),
          Text('Add items from the menu to get started.', style: TextStyle(color: Colors.black45)),
        ],
      ),
    );
  }

  Widget _buildCartItem(BuildContext ctx, QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    final name = d['name'] ?? 'Item';
    final priceRaw = d['price'] ?? 0;
    final price = (priceRaw is num) ? priceRaw.toDouble() : double.tryParse('$priceRaw') ?? 0.0;
    final qty = (d['quantity'] ?? 1) is num ? (d['quantity'] ?? 1).toInt() : int.tryParse('${d['quantity']}') ?? 1;

    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(child: Icon(Icons.fastfood, color: Colors.teal.shade700, size: 28)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 6),
                Text('₹${price.toStringAsFixed(2)}', style: TextStyle(color: Colors.teal.shade700, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    // decrement
                    Material(
                      color: Colors.grey.shade100,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      child: InkWell(
                        onTap: () => _decrementCartItem(doc),
                        borderRadius: BorderRadius.circular(8),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          child: Icon(Icons.remove, size: 18),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text('$qty', style: const TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(width: 8),
                    // increment
                    Material(
                      color: Colors.teal.shade700,
                      borderRadius: BorderRadius.circular(8),
                      child: InkWell(
                        onTap: () => _incrementCartItem(doc),
                        borderRadius: BorderRadius.circular(8),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          child: Icon(Icons.add, color: Colors.white, size: 18),
                        ),
                      ),
                    ),
                    const Spacer(),
                    Text('₹${(price * qty).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryPanel(double total, int itemsCount) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 12)],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Total', style: TextStyle(fontSize: 14, color: Colors.black54)),
                  const SizedBox(height: 4),
                  Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('$itemsCount items', style: const TextStyle(color: Colors.black54)),
                const SizedBox(height: 6),
                ElevatedButton.icon(
                  onPressed: _placing ? null : _confirmOrder,
                  icon: _placing ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.check_circle_outline),
                  label: Text(_placing ? 'Placing...' : 'Confirm Order'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    minimumSize: const Size(120, 42),
                  ),
                ),
              ]),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _paymentRefController,
                  decoration: InputDecoration(
                    labelText: 'Payment reference ID',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              IconButton(
                onPressed: () {
                  _paymentRefController.clear();
                },
                icon: Icon(Icons.clear, color: Colors.grey.shade600),
              )
            ],
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(body: Center(child: Text('Please sign in to view cart')));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.canteenName} Cart', style: const TextStyle(fontWeight: FontWeight.w600)),
        centerTitle: true,
        backgroundColor: Colors.teal.shade600,
        elevation: 0,
      ),
      backgroundColor: Colors.teal.shade50,
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _cartStream(user.uid),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final docs = snapshot.data!.docs;
          final total = _computeTotal(docs);

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Expanded(
                    child: docs.isEmpty
                        ? _buildEmptyCart()
                        : ListView.builder(
                            itemCount: docs.length,
                            itemBuilder: (ctx, i) => _buildCartItem(ctx, docs[i]),
                          ),
                  ),

                  const SizedBox(height: 12),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Want to Pre-Order?', style: TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 6),
                            GestureDetector(
                              onTap: () async {
                                await _loadCanteenHours();
                                final now = DateTime.now();

                                // Ensure we have canteen hours
                                final opens = _canteenOpens ?? TimeOfDay(hour: 8, minute: 0);
                                final closes = _canteenCloses ?? TimeOfDay(hour: 17, minute: 0);

                                // Build today's open/close DateTimes
                                final opensDt = _combineDateAndTime(now, opens);
                                final closesDt = _combineDateAndTime(now, closes);

                                // If canteen already closed today, disallow prebook
                                if (now.isAfter(closesDt)) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Prebook not available today — canteen already closed.')),
                                  );
                                  return;
                                }

                                // Minimum allowed time: now + 5 minutes
                                final minAllowedDt = now.add(const Duration(minutes: 5));

                                // If minAllowed is before opens, earliest allowed is opens
                                final earliestAllowedDt = minAllowedDt.isAfter(opensDt) ? minAllowedDt : opensDt;

                                // If earliest allowed is after closes -> not available
                                if (earliestAllowedDt.isAfter(closesDt)) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Prebook time not available within canteen hours today.')),
                                  );
                                  return;
                                }

                                // PREBOOK IS TODAY ONLY — skip date picker and jump straight to time
                                TimeOfDay initialTime = TimeOfDay.fromDateTime(earliestAllowedDt);

                                final pickedTime = await showTimePicker(
                                  context: context,
                                  initialTime: initialTime,
                                  builder: (context, child) => child ?? const SizedBox.shrink(),
                                );

                                if (pickedTime == null) return; // user cancelled

                                // Compose selected DateTime (today with pickedTime)
                                final selected = DateTime(now.year, now.month, now.day, pickedTime.hour, pickedTime.minute);

                                // Validate against earliest allowed and closing time
                                if (selected.isBefore(earliestAllowedDt)) {
                                  final fmt = DateFormat('hh:mm a');
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Please choose a time after ${fmt.format(earliestAllowedDt)}')),
                                  );
                                  return;
                                }
                                if (selected.isAfter(closesDt) || selected.isAtSameMomentAs(closesDt)) {
                                  final fmt = DateFormat('hh:mm a');
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Please choose a time before ${fmt.format(closesDt)}')),
                                  );
                                  return;
                                }

                                // All good — set prebook time to selected
                                setState(() => _prebookTime = selected);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8)],
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.calendar_today, color: Colors.teal.shade700),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        _prebookTime == null
                                            ? 'No time selected · Tap to pick (today only)'
                                            : DateFormat('yyyy-MM-dd · hh:mm a').format(_prebookTime!),
                                        style: TextStyle(color: _prebookTime == null ? Colors.black45 : Colors.black87),
                                      ),
                                    ),
                                    if (_prebookTime != null)
                                      IconButton(
                                        onPressed: () => setState(() => _prebookTime = null),
                                        icon: Icon(Icons.close, color: Colors.grey.shade600),
                                      )
                                  ],
                                ),
                              ),
                           ),

                          ],
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        flex: 1,
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8)]),
                              child: QrImageView(
                                data: 'upi://pay?pa=sreeharim776@oksbi&pn=WrapIt&am=${total.toStringAsFixed(2)}&tn=Order',
                                version: QrVersions.auto,
                                size: 120,
                                backgroundColor: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text('Scan to pay', style: TextStyle(color: Colors.black54)),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  _buildSummaryPanel(total, docs.length),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
