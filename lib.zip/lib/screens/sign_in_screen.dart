import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:canteen_app/screens/select_canteen_screen.dart';
import 'package:canteen_app/screens/canteen_list_screen.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _adminCodeController = TextEditingController();

  bool _isLogin = true;
  bool _loading = false;
  bool _isAdminSignup = false;

  final String _secretAdminCode = "WRAPIT2025ADMIN";

  Future<void> _authenticate() async {
    setState(() => _loading = true);
    try {
      final auth = FirebaseAuth.instance;
      final firestore = FirebaseFirestore.instance;
      UserCredential credential;

      if (_isLogin) {
        credential = await auth.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        final userDoc = await firestore.collection('users').doc(credential.user!.uid).get();
        final role = userDoc.data()?['role']?.toString() ?? 'user';

        if (!mounted) return;
        if (role == 'admin' || role == 'pending_admin') {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SelectCanteenScreen()));
        } else {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CanteenListScreen()));
        }

        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Login successful!')));
      } else {
        String role = 'user';
        if (_isAdminSignup) {
          if (_adminCodeController.text.trim() != _secretAdminCode) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid admin code!'), backgroundColor: Colors.red));
            setState(() => _loading = false);
            return;
          }
          role = 'pending_admin';
        }

        credential = await auth.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        await firestore.collection('users').doc(credential.user!.uid).set({
          'email': _emailController.text.trim(),
          'role': role,
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        if (!mounted) return;
        if (role == 'pending_admin') {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SelectCanteenScreen()));
        } else {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CanteenListScreen()));
        }

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Account created as $role')));
      }
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Authentication failed')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _adminCodeController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: Colors.teal),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal.shade700, Colors.teal.shade400],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        Positioned(
          top: -60,
          left: -60,
          child: Container(
            width: 220,
            height: 220,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(120),
            ),
          ),
        ),
        Positioned(
          top: 40,
          right: -40,
          child: Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(70),
            ),
          ),
        ),
        Positioned(
          bottom: -70,
          right: -70,
          child: Container(
            width: 260,
            height: 260,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.04),
              borderRadius: BorderRadius.circular(130),
            ),
          ),
        ),
        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 36),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [Colors.white.withOpacity(0.12), Colors.white.withOpacity(0.08)]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, 8))],
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Row(children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                        child: Icon(Icons.fastfood, size: 36, color: Colors.teal.shade700),
                      ),
                      const SizedBox(width: 14),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_isLogin ? 'Welcome Back' : 'Create Account', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 6),
                        Text('Fast, fresh canteen ordering', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 13)),
                      ])
                    ]),
                  ),
                  const SizedBox(height: 22),
                  Card(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 6,
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Column(children: [
                        TextField(controller: _emailController, keyboardType: TextInputType.emailAddress, decoration: _inputDecoration('Email', Icons.email)),
                        const SizedBox(height: 12),
                        TextField(controller: _passwordController, obscureText: true, decoration: _inputDecoration('Password', Icons.lock)),
                        if (!_isLogin && _isAdminSignup) ...[
                          const SizedBox(height: 12),
                          TextField(controller: _adminCodeController, obscureText: true, decoration: _inputDecoration('Admin Secret Code', Icons.security)),
                        ],
                        const SizedBox(height: 18),
                        _loading
                            ? const SizedBox(height: 50, child: Center(child: CircularProgressIndicator()))
                            : SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _authenticate,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal.shade700,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                  child: Text(_isLogin ? 'Sign In' : 'Register', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                                ),
                              ),
                        const SizedBox(height: 12),
                        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          TextButton(onPressed: () => setState(() => _isLogin = !_isLogin), child: Text(_isLogin ? "Don't have an account? Register" : "Already have an account? Sign in", style: TextStyle(color: Colors.teal.shade700))),
                        ]),
                        if (!_isLogin)
                          TextButton(onPressed: () => setState(() => _isAdminSignup = !_isAdminSignup), child: Text(_isAdminSignup ? 'Switch to User Signup' : 'Sign up as Admin (with code)', style: TextStyle(color: Colors.teal.shade700))),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(child: Divider(color: Colors.white.withOpacity(0.14), thickness: 1)),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('OR', style: TextStyle(color: Colors.white.withOpacity(0.9)))),
                    Expanded(child: Divider(color: Colors.white.withOpacity(0.14), thickness: 1)),
                  ]),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final auth = FirebaseAuth.instance;
                        await auth.signInAnonymously();
                        final user = auth.currentUser;
                        if (user == null) return;
                        final firestore = FirebaseFirestore.instance;
                        await firestore.collection('users').doc(user.uid).set({
                          'email': 'guest',
                          'role': 'user',
                          'createdAt': FieldValue.serverTimestamp(),
                        }, SetOptions(merge: true));
                        if (!mounted) return;
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CanteenListScreen()));
                      },
                      icon: Icon(Icons.person_outline, color: Colors.teal.shade700),
                      label: const Text('Continue as Guest', style: TextStyle(color: Colors.black87)),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        side: BorderSide(color: Colors.white.withOpacity(0.14)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        backgroundColor: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
