import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:canteen_app/screens/select_canteen_screen.dart';
import 'package:canteen_app/screens/canteen_list_screen.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _adminCodeController = TextEditingController();

  bool _isLogin = true;
  bool _loading = false;
  bool _isAdminSignup = false;

  final String _secretAdminCode = "WRAPIT2025ADMIN"; 

  Future<void> _authenticate() async {
    setState(() => _loading = true);
    try {
      final auth = FirebaseAuth.instance;
      final firestore = FirebaseFirestore.instance;
      UserCredential credential;

      if (_isLogin) {
        credential = await auth.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        final userDoc = await firestore.collection('users').doc(credential.user!.uid).get();
        final role = userDoc.data()?['role']?.toString() ?? 'user';

        if (!mounted) return;
        if (role == 'admin' || role == 'pending_admin') {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SelectCanteenScreen()));
        } else {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CanteenListScreen()));
        }

        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Login successful!')));
      } else {
        String role = 'user';
        if (_isAdminSignup) {
          if (_adminCodeController.text.trim() != _secretAdminCode) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid admin code!'), backgroundColor: Colors.red));
            setState(() => _loading = false);
            return;
          }
          role = 'pending_admin';
        }

        credential = await auth.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        await firestore.collection('users').doc(credential.user!.uid).set({
          'email': _emailController.text.trim(),
          'role': role,
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        if (!mounted) return;
        if (role == 'pending_admin') {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SelectCanteenScreen()));
        } else {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CanteenListScreen()));
        }

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Account created as $role')));
      }
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Authentication failed')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _adminCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(
        title: const Text('Canteen Login'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Icon(Icons.fastfood, size: 90, color: Colors.teal.shade400),
                const SizedBox(height: 20),
                Text(_isLogin ? 'Welcome Back' : 'Create an Account', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 30),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    prefixIcon: const Icon(Icons.email),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                if (!_isLogin && _isAdminSignup)
                  TextField(
                    controller: _adminCodeController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: 'Admin Secret Code',
                      prefixIcon: const Icon(Icons.security),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                const SizedBox(height: 16),
                _loading
                    ? const CircularProgressIndicator()
                    : Column(
                        children: [
                          ElevatedButton(
                            onPressed: _authenticate,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              foregroundColor: Colors.white,
                              minimumSize: const Size(double.infinity, 50),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: Text(_isLogin ? 'Sign In' : 'Register'),
                          ),
                          const SizedBox(height: 10),
                          if (!_isLogin)
                            TextButton(
                              onPressed: () => setState(() {
                                _isAdminSignup = !_isAdminSignup;
                              }),
                              child: Text(_isAdminSignup ? 'Switch to User Signup' : 'Sign up as Admin (with code)', style: const TextStyle(color: Colors.teal)),
                            ),
                          const SizedBox(height: 10),
                          TextButton(
                            onPressed: () => setState(() => _isLogin = !_isLogin),
                            child: Text(_isLogin ? 'Don\'t have an account? Register' : 'Already have an account? Sign in', style: const TextStyle(color: Colors.teal)),
                          ),
                        ],
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
