import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/admin/admin_dashboard.dart';
import 'package:canteen_app/utils/auth_utils.dart';

class SelectCanteenScreen extends StatefulWidget {
  const SelectCanteenScreen({super.key});

  @override
  State<SelectCanteenScreen> createState() => _SelectCanteenScreenState();
}

class _SelectCanteenScreenState extends State<SelectCanteenScreen> {
  String? selectedCanteenId;
  final _passwordController = TextEditingController();
  bool _loading = false;

  late StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _notifSub;
  bool _notifListenerActive = false;

  void _startNotificationListener() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    if (_notifListenerActive) return;
    _notifListenerActive = true;

    _notifSub = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('notifications')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen((snap) {
      for (final change in snap.docChanges) {
        if (change.type == DocumentChangeType.added) {
          final data = change.doc.data();
          if (data == null) continue;
          final title = (data['title'] ?? 'Notification').toString();
          final body = (data['body'] ?? '').toString();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('$title — $body'),
                duration: const Duration(seconds: 4),
                action: SnackBarAction(
                  label: 'View',
                  onPressed: () {
                    // optional: navigate to a relevant screen
                  },
                ),
              ),
            );
          }
          // Non-critical: mark read (best-effort)
          try {
            change.doc.reference.set({'read': true}, SetOptions(merge: true));
          } catch (e) {
            debugPrint('Failed to mark notification read: $e');
          }
        }
      }
    }, onError: (err) {
      debugPrint('Notification listener error: $err');
    });
  }

  @override
  void initState() {
    super.initState();
    _notifSub = null;
    _startNotificationListener();
  }

  @override
  void dispose() {
    _passwordController.dispose();
    if (_notifListenerActive) {
      _notifSub?.cancel();
      _notifListenerActive = false;
    }
    super.dispose();
  }

  Future<void> _verifyCanteen() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    if (selectedCanteenId == null || _passwordController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a canteen and enter password'),
        ),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final canteenDoc = await FirebaseFirestore.instance.collection('canteens').doc(selectedCanteenId).get();
      if (!canteenDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Canteen not found.')));
        return;
      }

      final data = canteenDoc.data() ?? {};
      // stored password may be null — use empty string to avoid crashes
      final storedPassword = (data['password'] ?? '').toString();

      if (storedPassword == _passwordController.text.trim()) {
        // Write canteenId to user doc (merge to preserve role etc.)
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'canteenId': selectedCanteenId,
        }, SetOptions(merge: true));

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Canteen verified!'), backgroundColor: Colors.green),
        );

        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboard()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Incorrect password!'), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final canteensStream = FirebaseFirestore.instance.collection('canteens').snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Canteen'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.red),
            tooltip: 'Logout',
            onPressed: () => AuthUtils.logout(context),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: canteensStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final canteens = snapshot.data!.docs;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text('Select your canteen and enter its password', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                const SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: canteens.length,
                    itemBuilder: (context, index) {
                      final canteen = canteens[index];
                      final name = (canteen.data()['name'] ?? canteen.id).toString();
                      return RadioListTile<String>(
                        title: Text(name),
                        value: canteen.id,
                        groupValue: selectedCanteenId,
                        onChanged: (value) {
                          setState(() => selectedCanteenId = value);
                        },
                      );
                    },
                  ),
                ),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Canteen Password',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 20),
                _loading
                    ? const CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: _verifyCanteen,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          foregroundColor: Colors.white,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('Verify & Continue'),
                      ),
              ],
            ),
          );
        },
      ),
    );
  }
}
