import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/admin/admin_dashboard.dart';
import 'package:canteen_app/utils/auth_utils.dart';

class SelectCanteenScreen extends StatefulWidget {
  const SelectCanteenScreen({super.key});

  @override
  State<SelectCanteenScreen> createState() => _SelectCanteenScreenState();
}

class _SelectCanteenScreenState extends State<SelectCanteenScreen> {
  String? selectedCanteenId;
  final _passwordController = TextEditingController();
  bool _loading = false;

  late StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _notifSub;
  bool _notifListenerActive = false;

  // UI state
  String _searchTerm = '';

  void _startNotificationListener() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    if (_notifListenerActive) return;
    _notifListenerActive = true;

    _notifSub = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('notifications')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen((snap) {
      for (final change in snap.docChanges) {
        if (change.type == DocumentChangeType.added) {
          final data = change.doc.data();
          if (data == null) continue;
          final title = (data['title'] ?? 'Notification').toString();
          final body = (data['body'] ?? '').toString();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('$title — $body'),
                duration: const Duration(seconds: 4),
                action: SnackBarAction(
                  label: 'View',
                  onPressed: () {
                    // optionally navigate to something
                  },
                ),
              ),
            );
          }
          try {
            change.doc.reference.set({'read': true}, SetOptions(merge: true));
          } catch (e) {
            debugPrint('Failed to mark notification read: $e');
          }
        }
      }
    }, onError: (err) {
      debugPrint('Notification listener error: $err');
    });
  }

  @override
  void initState() {
    super.initState();
    _notifSub = null;
    _startNotificationListener();
  }

  @override
  void dispose() {
    _passwordController.dispose();
    if (_notifListenerActive) {
      _notifSub?.cancel();
      _notifListenerActive = false;
    }
    super.dispose();
  }

  Future<void> _verifyCanteen() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    if (selectedCanteenId == null || _passwordController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a canteen and enter password'),
        ),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final canteenDoc = await FirebaseFirestore.instance.collection('canteens').doc(selectedCanteenId).get();
      if (!canteenDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Canteen not found.')));
        return;
      }

      final data = canteenDoc.data() ?? {};
      final storedPassword = (data['password'] ?? '').toString();

      if (storedPassword == _passwordController.text.trim()) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'canteenId': selectedCanteenId,
        }, SetOptions(merge: true));

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Canteen verified!'), backgroundColor: Colors.green),
        );

        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboard()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Incorrect password!'), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<QueryDocumentSnapshot<Map<String, dynamic>>> _filterCanteens(
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    if (_searchTerm.trim().isEmpty) return docs;
    final q = _searchTerm.trim().toLowerCase();
    return docs.where((d) {
      final name = (d.data()['name'] ?? d.id).toString().toLowerCase();
      final desc = (d.data()['description'] ?? '').toString().toLowerCase();
      return name.contains(q) || desc.contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final canteensStream = FirebaseFirestore.instance.collection('canteens').snapshots();

    return Scaffold(
      // subtle gradient header + logout
      appBar: AppBar(
        title: const Text('Select Canteen'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
        toolbarHeight: 68,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10.0),
            child: IconButton(
              icon: const Icon(Icons.logout, color: Colors.red),
              tooltip: 'Logout',
              onPressed: () => AuthUtils.logout(context),
            ),
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // stylish background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.teal.shade700, Colors.teal.shade300.withOpacity(0.9)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),

          // main content card
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 12),
              child: Column(
                children: [
                  // hero header
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, 6))],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 68,
                          height: 68,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8)],
                          ),
                          child: Center(
                            child: Text('W', style: TextStyle(color: Colors.teal.shade700, fontSize: 28, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Welcome, Admin', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 6),
                              Text('Choose the canteen you manage', style: TextStyle(color: Colors.white.withOpacity(0.9))),
                            ],
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () {
                            // quick help / info
                            showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('How to proceed'),
                                content: const Text('Select the canteen you manage, enter the canteen password and tap Verify & Continue.'),
                                actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
                              ),
                            );
                          },
                          icon: const Icon(Icons.help_outline, size: 18),
                          label: const Text('Help'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.teal.shade700,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                        )
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // search field
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8)],
                    ),
                    child: TextField(
                      onChanged: (v) => setState(() => _searchTerm = v),
                      style: const TextStyle(color: Colors.black87),
                      decoration: InputDecoration(
                        icon: const Icon(Icons.search),
                        hintText: 'Search canteens by name or description',
                        border: InputBorder.none,
                        suffixIcon: _searchTerm.isNotEmpty
                            ? IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => _searchTerm = ''))
                            : null,
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // list of canteens (cards)
                  Expanded(
                    child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: canteensStream,
                      builder: (context, snapshot) {
                        if (snapshot.hasError) {
                          return Center(child: Text('Error: ${snapshot.error}', style: const TextStyle(color: Colors.white)));
                        }
                        if (!snapshot.hasData) {
                          return const Center(child: CircularProgressIndicator.adaptive());
                        }

                        final canteens = _filterCanteens(snapshot.data!.docs);
                        if (canteens.isEmpty) {
                          return Center(child: Text('No canteens found', style: TextStyle(color: Colors.white70)));
                        }

                        return ListView.separated(
                          itemCount: canteens.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          padding: const EdgeInsets.only(bottom: 12, top: 6),
                          itemBuilder: (context, i) {
                            final doc = canteens[i];
                            final d = doc.data();
                            final name = (d['name'] ?? doc.id).toString();
                            final desc = (d['description'] ?? '').toString();
                            final location = (d['location'] ?? '').toString();
                            final meta = <String>[];
                            if (location.isNotEmpty) meta.add(location);
                            if ((d['capacity'] ?? '').toString().isNotEmpty) meta.add('Capacity: ${d['capacity']}');

                            final isSelected = selectedCanteenId == doc.id;

                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 280),
                              curve: Curves.easeOutCubic,
                              margin: const EdgeInsets.symmetric(horizontal: 2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                boxShadow: [
                                  BoxShadow(color: Colors.black.withOpacity(isSelected ? 0.14 : 0.06), blurRadius: isSelected ? 18 : 10, offset: const Offset(0, 8)),
                                ],
                                border: Border.all(color: isSelected ? Colors.white.withOpacity(0.14) : Colors.white.withOpacity(0.04)),
                              ),
                              child: Material(
                                color: isSelected ? Colors.white : Colors.white.withOpacity(0.9),
                                borderRadius: BorderRadius.circular(14),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: () {
                                    setState(() => selectedCanteenId = doc.id);
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Row(
                                      children: [
                                        // avatar / glyph
                                        Container(
                                          width: 56,
                                          height: 56,
                                          decoration: BoxDecoration(
                                            color: isSelected ? Colors.teal.shade700 : Colors.teal.shade50,
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: Center(
                                            child: Text(
                                              name.isNotEmpty ? name[0].toUpperCase() : 'C',
                                              style: TextStyle(
                                                color: isSelected ? Colors.white : Colors.teal.shade700,
                                                fontSize: 22,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 12),

                                        // details
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: Text(
                                                      name,
                                                      style: TextStyle(
                                                        fontSize: 16,
                                                        fontWeight: FontWeight.w700,
                                                        color: isSelected ? Colors.teal.shade900 : Colors.black87,
                                                      ),
                                                      maxLines: 1,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 6),
                                                  AnimatedContainer(
                                                    duration: const Duration(milliseconds: 280),
                                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                                    decoration: BoxDecoration(
                                                      color: isSelected ? Colors.teal.shade700 : Colors.transparent,
                                                      borderRadius: BorderRadius.circular(8),
                                                    ),
                                                    child: Icon(
                                                      isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                                                      color: isSelected ? Colors.white : Colors.grey.shade500,
                                                      size: 20,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 6),
                                              Text(
                                                desc.isNotEmpty ? desc : (meta.isNotEmpty ? meta.join(' · ') : 'No additional info'),
                                                style: TextStyle(color: Colors.black54),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),

                  // password + CTA (sticky)
                  Container(
                    margin: const EdgeInsets.only(top: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.95),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10)],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _passwordController,
                                obscureText: true,
                                decoration: InputDecoration(
                                  labelText: 'Canteen Password',
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Tooltip(
                              message: 'If you don\'t know the password, contact your canteen admin.',
                              child: Icon(Icons.lock_outline, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        _loading
                            ? const SizedBox(height: 46, child: Center(child: CircularProgressIndicator()))
                            : SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _verifyCanteen,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal.shade700,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  ),
                                  child: const Text('Verify & Continue', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                                ),
                              ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
