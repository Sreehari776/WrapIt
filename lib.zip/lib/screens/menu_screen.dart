import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/screens/cart_screen.dart';
import 'package:canteen_app/screens/orders_screen.dart';

class MenuScreen extends StatefulWidget {
  final String canteenId;
  final String canteenName;

  const MenuScreen({
    super.key,
    required this.canteenId,
    required this.canteenName,
  });

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _searchCtl = TextEditingController();
  String _query = '';
  String _selectedCategory = 'All';
  List<String> _categories = [];
  late final AnimationController _listAnimCtrl;

  @override
  void initState() {
    super.initState();
    _listAnimCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _listAnimCtrl.forward();
  }

  @override
  void dispose() {
    _searchCtl.dispose();
    _listAnimCtrl.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _normalizeMenuToList(dynamic menuRaw) {
    if (menuRaw == null) return <Map<String, dynamic>>[];

    if (menuRaw is List) {
      return menuRaw
          .where((e) => e is Map)
          .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }

    if (menuRaw is Map) {
      final Map m = menuRaw;
      if (m.containsKey('name') && m.containsKey('price')) {
        return [Map<String, dynamic>.from(m)];
      }
      final List<Map<String, dynamic>> items = [];
      for (final key in m.keys) {
        final val = m[key];
        if (val is Map) {
          final item = Map<String, dynamic>.from(val);
          if (!item.containsKey('id')) item['id'] = key;
          items.add(item);
        }
      }
      return items;
    }
    return <Map<String, dynamic>>[];
  }

  Future<void> addToCartDebug(BuildContext context, Map<String, dynamic> item) async {
    debugPrint('addToCartDebug: started for item: ${jsonEncode(item)}');

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Adding to cart'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 12),
            Text('Adding ${item['name'] ?? 'item'}...'),
          ],
        ),
      ),
    );

    try {
      final user = FirebaseAuth.instance.currentUser;
      debugPrint('addToCartDebug: currentUser=${user?.uid}');
      if (user == null) return; 

      final userCart = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('cart');

      final existing = await userCart.limit(1).get();
      if (existing.docs.isNotEmpty) {
        final existingCanteen = existing.docs.first.data()['canteen'] as String?;
        debugPrint('addToCartDebug: existingCanteen=$existingCanteen');
        if (existingCanteen != null && existingCanteen != widget.canteenName) {
          Navigator.of(context, rootNavigator: true).pop();
          await showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Cannot add'),
              content: const Text('You can only order from one canteen at a time.'),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
            ),
          );
          return;
        }
      }

      final rawId = item['id']?.toString();
      final fallbackId = (item['name'] ?? DateTime.now().millisecondsSinceEpoch.toString())
          .toString()
          .replaceAll(RegExp(r'\s+'), '_')
          .toLowerCase();
      final docId = (rawId?.isNotEmpty == true) ? rawId! : fallbackId;

      final cartDocRef = userCart.doc(docId);

      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(cartDocRef);
        if (!snap.exists) {
          num price = 0;
          final rp = item['price'];
          if (rp is num) price = rp;
          else if (rp is String) price = num.tryParse(rp) ?? 0;

          tx.set(cartDocRef, {
            'itemId': item['id'] ?? docId,
            'name': item['name'] ?? 'Item',
            'price': price,
            'category': item['category'] ?? '',
            'canteen': widget.canteenName,
            'quantity': 1,
            'addedAt': FieldValue.serverTimestamp(),
          });
        } else {
          final currentQty = (snap.data()?['quantity'] ?? 0);
          final int newQty = (currentQty is int) ? currentQty + 1 : int.tryParse(currentQty.toString()) ?? 1;
          tx.update(cartDocRef, {
            'quantity': newQty,
            'lastUpdated': FieldValue.serverTimestamp(),
          });
        }
      });

      debugPrint('addToCartDebug: success for $docId');

      Navigator.of(context, rootNavigator: true).pop();
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Added'),
          content: Text('${item['name'] ?? 'Item'} added to cart.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
    } catch (e, st) {
      debugPrint('addToCartDebug: ERROR -> $e\n$st');
      Navigator.of(context, rootNavigator: true).pop();
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Error'),
          content: Text('Failed to add item to cart: $e'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
    }
  }

  PreferredSizeWidget _buildTopBar() {
  return AppBar(
    backgroundColor: Colors.transparent,
    elevation: 0,
    foregroundColor: Colors.black,
    title: const Text ('Menu', style: TextStyle(fontWeight: FontWeight.bold)),

    leading: IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        FocusManager.instance.primaryFocus?.unfocus();
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
          return;
        }
        Navigator.of(context).pushReplacementNamed('/');
      },
    ),
    actions: [
      IconButton(
        icon: const Icon(Icons.receipt_long),
        onPressed: () {
          FocusManager.instance.primaryFocus?.unfocus();
          Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersScreen()));
        },
      ),
      IconButton(
        icon: const Icon(Icons.shopping_cart),
        onPressed: () {
          FocusManager.instance.primaryFocus?.unfocus();
          Navigator.push(context, MaterialPageRoute(builder: (_) => 
          CartScreen(canteenId: widget.canteenId, 
          canteenName: widget.canteenName)));
        },
      )
    ],
  );
}

  

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchCtl,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search menu item or category',
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
            ),
          ),
          const SizedBox(width: 10),
          ElevatedButton(
            onPressed: () {
              _searchCtl.clear();
              setState(() {
                _query = '';
                _selectedCategory = 'All';
              });
            },
            child: const Icon(Icons.clear),
            style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.all(12)),
          )
        ],
      ),
    );
  }

  Widget _buildCategoryChips() {
    final chips = <Widget>[];
    chips.add(_categoryChip('All'));
    for (final c in _categories) {
      chips.add(_categoryChip(c));
    }
    return SizedBox(
      height: 46,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, i) => chips[i],
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemCount: chips.length,
      ),
    );
  }

  Widget _categoryChip(String name) {
    final selected = name == _selectedCategory;
    return ChoiceChip(
      label: Text(name, style: TextStyle(color: selected ? Colors.white : Colors.black87)),
      selected: selected,
      onSelected: (_) => setState(() => _selectedCategory = name),
      selectedColor: Colors.teal,
      backgroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    );
  }

  List<Map<String, dynamic>> _filterMenu(List<Map<String, dynamic>> all) {
    final q = _query;
    final category = _selectedCategory;
    var filtered = all.where((m) {
      final name = (m['name'] ?? '').toString().toLowerCase();
      final cat = (m['category'] ?? '').toString().toLowerCase();
      if (q.isNotEmpty && !name.contains(q) && !cat.contains(q)) return false;
      if (category != 'All' && category.toLowerCase() != cat.toLowerCase()) return false;
      return true;
    }).toList();
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('canteens').doc(widget.canteenId).snapshots();

    return Scaffold(
      appBar: _buildTopBar(),
      backgroundColor: Colors.teal.shade50,
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData || !snapshot.data!.exists) return const Center(child: CircularProgressIndicator());

          final data = snapshot.data!.data();
          if (data == null || data['menu'] == null) return const Center(child: Text('No menu found.'));

          final menuList = _normalizeMenuToList(data['menu']);
          if (menuList.isEmpty) return const Center(child: Text('No menu items.'));

          final cats = <String>{};
          for (final m in menuList) {
            final c = (m['category'] ?? '').toString().trim();
            if (c.isNotEmpty) cats.add(c);
          }
          _categories = cats.toList();

          final filtered = _filterMenu(menuList);

          return Column(
            children: [
              _buildSearchBar(),
              const SizedBox(height: 6),
              if (_categories.isNotEmpty) _buildCategoryChips(),
              const SizedBox(height: 8),
              Expanded(
                child: AnimatedBuilder(
                  animation: _listAnimCtrl,
                  builder: (context, _) {
                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final item = filtered[index];
                        final name = item['name']?.toString() ?? 'Item';
                        final price = item['price'] ?? 0;
                        final priceStr = (price is num) ? price.toStringAsFixed(2) : price.toString();
                        final category = (item['category'] ?? '').toString();
                        final description = (item['description'] ?? '').toString();
                        final id = item['id']?.toString() ?? index.toString();

                        final anim = CurvedAnimation(parent: _listAnimCtrl, curve: Interval(0.0, 1.0, curve: Curves.easeOut));
                        final tileScale = 0.96 + 0.04 * (anim.value);

                        return Transform.scale(
                          scale: tileScale,
                          child: Card(
                            elevation: 2,
                            margin: const EdgeInsets.symmetric(vertical: 6),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: () {},
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 64,
                                      height: 64,
                                      decoration: BoxDecoration(
                                        color: Colors.teal.shade50,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                        child: Icon(Icons.fastfood, color: Colors.teal.shade700, size: 30),
                                      ),
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                                              Text('₹$priceStr', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
                                            ],
                                          ),
                                          const SizedBox(height: 6),
                                          Row(
                                            children: [
                                              Expanded(child: Text(description.isEmpty ? category : description, style: const TextStyle(color: Colors.black54))),
                                            ],
                                          ),
                                          const SizedBox(height: 8),
                                          Row(
                                            children: [
                                              OutlinedButton.icon(
                                                onPressed: () async {
                                                  await addToCartDebug(context, item);
                                                },
                                                icon: const Icon(Icons.add_shopping_cart_outlined, size: 18),
                                                label: const Text('Add'),
                                                style: OutlinedButton.styleFrom(
                                                  foregroundColor: Colors.teal.shade800,
                                                  side: BorderSide(color: Colors.teal.shade100),
                                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                                ),
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
