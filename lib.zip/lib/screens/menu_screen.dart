// menu_screen.dart (debug-friendly)
// Replace your current file with this to debug the plus-button behavior.

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/screens/cart_screen.dart';
import 'package:canteen_app/screens/orders_screen.dart';

class MenuScreen extends StatelessWidget {
  final String canteenId;
  final String canteenName;

  const MenuScreen({
    super.key,
    required this.canteenId,
    required this.canteenName,
  });

  List<Map<String, dynamic>> _normalizeMenuToList(dynamic menuRaw) {
    if (menuRaw == null) return <Map<String, dynamic>>[];

    if (menuRaw is List) {
      return menuRaw
          .where((e) => e is Map)
          .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }

    if (menuRaw is Map) {
      final Map m = menuRaw;
      if (m.containsKey('name') && m.containsKey('price')) {
        return [Map<String, dynamic>.from(m)];
      }
      final List<Map<String, dynamic>> items = [];
      for (final key in m.keys) {
        final val = m[key];
        if (val is Map) {
          final item = Map<String, dynamic>.from(val);
          if (!item.containsKey('id')) item['id'] = key;
          items.add(item);
        }
      }
      return items;
    }
    return <Map<String, dynamic>>[];
  }

  // Debug-friendly, visible add-to-cart
Future<void> addToCartDebug(BuildContext context, Map<String, dynamic> item) async {
  debugPrint('addToCartDebug: started for item: ${jsonEncode(item)}');

  // Show progress dialog (do NOT await - we want code to continue)
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      title: const Text('Adding to cart'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 12),
          Text('Adding ${item['name'] ?? 'item'}...'),
        ],
      ),
    ),
  );

  try {
    final user = FirebaseAuth.instance.currentUser;
    debugPrint('addToCartDebug: currentUser=${user?.uid}');
    if (user == null) {
      // close progress dialog then show "not signed in"
      Navigator.of(context, rootNavigator: true).pop();
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Not signed in'),
          content: const Text('You must sign in to add items to the cart.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      return;
    }

    final userCart = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('cart');

    // guard for different-canteen items
    final existing = await userCart.limit(1).get();
    if (existing.docs.isNotEmpty) {
      final existingCanteen = existing.docs.first.data()['canteen'] as String?;
      debugPrint('addToCartDebug: existingCanteen=$existingCanteen');
      if (existingCanteen != null && existingCanteen != canteenName) {
        Navigator.of(context, rootNavigator: true).pop();
        await showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Cannot add'),
            content: const Text('You can only order from one canteen at a time.'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
          ),
        );
        return;
      }
    }

    final rawId = item['id']?.toString();
    final fallbackId = (item['name'] ?? DateTime.now().millisecondsSinceEpoch.toString())
        .toString()
        .replaceAll(RegExp(r'\s+'), '_')
        .toLowerCase();
    final docId = (rawId?.isNotEmpty == true) ? rawId! : fallbackId;

    final cartDocRef = userCart.doc(docId);

    // Transaction to create or increment
    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(cartDocRef);
      if (!snap.exists) {
        num price = 0;
        final rp = item['price'];
        if (rp is num) price = rp;
        else if (rp is String) price = num.tryParse(rp) ?? 0;

        tx.set(cartDocRef, {
          'itemId': item['id'] ?? docId,
          'name': item['name'] ?? 'Item',
          'price': price,
          'category': item['category'] ?? '',
          'canteen': canteenName,
          'quantity': 1,
          'addedAt': FieldValue.serverTimestamp(),
        });
      } else {
        final currentQty = (snap.data()?['quantity'] ?? 0);
        final int newQty = (currentQty is int) ? currentQty + 1 : int.tryParse(currentQty.toString()) ?? 1;
        tx.update(cartDocRef, {
          'quantity': newQty,
          'lastUpdated': FieldValue.serverTimestamp(),
        });
      }
    });

    debugPrint('addToCartDebug: success for $docId');

    // close progress dialog and show success
    Navigator.of(context, rootNavigator: true).pop();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Added'),
        content: Text('${item['name'] ?? 'Item'} added to cart.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  } catch (e, st) {
    debugPrint('addToCartDebug: ERROR -> $e\n$st');
    // close progress dialog then show the error
    Navigator.of(context, rootNavigator: true).pop();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Error'),
        content: Text('Failed to add item to cart: $e'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }
}


  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('canteens').doc(canteenId).snapshots();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        title: Text('$canteenName Menu'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            tooltip: 'View Cart',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => CartScreen(canteenId: canteenId, canteenName: canteenName)));
            },
          ),
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'View Orders',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersScreen()));
            },
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          debugPrint('MenuScreen: snapshot.hasError=${snapshot.hasError}, conn=${snapshot.connectionState}');
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.data();
          if (data == null || data['menu'] == null) {
            return const Center(child: Text('No menu found.'));
          }

          final menuList = _normalizeMenuToList(data['menu']);

          if (menuList.isEmpty) return const Center(child: Text('No menu items.'));

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            itemCount: menuList.length,
            itemBuilder: (context, index) {
              final item = menuList[index];
              final itemName = item['name']?.toString() ?? 'Item';
              final priceStr = (item['price']?.toString() ?? '0');

              return Card(
                margin: const EdgeInsets.symmetric(vertical: 6),
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                  leading: CircleAvatar(backgroundColor: Colors.teal.shade100, child: const Icon(Icons.fastfood, color: Colors.teal)),
                  title: Text(itemName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  subtitle: Text(item['category']?.toString() ?? '', style: const TextStyle(color: Colors.black54)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('₹$priceStr', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
                      const SizedBox(width: 10),
                      IconButton(
                        icon: const Icon(Icons.add_circle, size: 26),
                        color: Colors.teal,
                        onPressed: () async {
                          debugPrint('IconButton pressed for ${item['name']}');
                          await addToCartDebug(context, item);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
