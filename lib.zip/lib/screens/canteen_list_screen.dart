import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'menu_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/utils/auth_utils.dart';
import 'dart:async';
import 'package:intl/intl.dart';

class NotificationIcon extends StatelessWidget {
  const NotificationIcon({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();

    final notifQuery = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('notifications')
        .where('read', isEqualTo: false);

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: notifQuery.snapshots(),
      builder: (context, snap) {
        int unread = 0;
        if (snap.hasData) unread = snap.data!.docs.length;

        return Stack(
          alignment: Alignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_none),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const _InlineNotificationsScreen()),
                );
              },
            ),
            if (unread > 0)
              Positioned(
                right: 6,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  constraints: const BoxConstraints(minWidth: 20, minHeight: 18),
                  child: Text(
                    unread > 99 ? '99+' : '$unread',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _InlineNotificationsScreen extends StatefulWidget {
  const _InlineNotificationsScreen({super.key});
  @override
  State<_InlineNotificationsScreen> createState() => _InlineNotificationsScreenState();
}

class _InlineNotificationsScreenState extends State<_InlineNotificationsScreen> {
  Stream<QuerySnapshot<Map<String, dynamic>>>? _stream;

  @override
  void initState() {
    super.initState();
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      _stream = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('notifications')
          .orderBy('timestamp', descending: true)
          .snapshots();
    }
  }

  String _formatTimestamp(dynamic ts) {
    try {
      if (ts == null) return '';
      if (ts is Timestamp) {
        final dt = ts.toDate().toLocal();
        return DateFormat('dd MMM • hh:mm a').format(dt);
      }
      return ts.toString();
    } catch (_) {
      return '';
    }
  }

  Future<void> _markRead(DocumentReference<Map<String, dynamic>> ref) async {
    try {
      await ref.set({'read': true}, SetOptions(merge: true));
    } catch (e) {
      debugPrint('markRead error: $e');
    }
  }

  Future<void> _markAllRead(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) async {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in docs) {
      batch.set(d.reference, {'read': true}, SetOptions(merge: true));
    }
    try {
      await batch.commit();
    } catch (e) {
      debugPrint('markAllRead error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: const Center(child: Text('Please sign in')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snap) {
              if (!snap.hasData) return const SizedBox.shrink();
              final docs = snap.data!.docs;
              if (docs.isEmpty) return const SizedBox.shrink();
              return TextButton(
                onPressed: () => _markAllRead(docs),
                child: const Text('Mark all read', style: TextStyle(color: Colors.white)),
              );
            },
          )
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());

          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('No notifications yet'));

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final doc = docs[i];
              final data = doc.data();
              final title = (data['title'] ?? 'Notification').toString();
              final body = (data['body'] ?? '').toString();
              final ts = _formatTimestamp(data['timestamp']);
              final read = (data['read'] ?? false) == true;

              return ListTile(
                tileColor: read ? Colors.white : Colors.teal.shade50,
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 6),
                    Text(body),
                    const SizedBox(height: 6),
                    Text(ts, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  ],
                ),
                trailing: read
                    ? null
                    : TextButton(
                        onPressed: () async {
                          await _markRead(doc.reference);
                        },
                        child: const Text('Mark read'),
                      ),
                onTap: () async {
                  await _markRead(doc.reference);
                },
              );
            },
          );
        },
      ),
    );
  }
}

class CanteenListScreen extends StatefulWidget {
  const CanteenListScreen({super.key});

  @override
  State<CanteenListScreen> createState() => _CanteenListScreenState();
}

class _CanteenListScreenState extends State<CanteenListScreen> {
  final TextEditingController _searchCtl = TextEditingController();
  String _query = '';
  bool _loadingRefresh = false;

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _loadingRefresh = true);
    try {
      await FirebaseFirestore.instance.collection('canteens').get();
      await Future.delayed(const Duration(milliseconds: 400));
    } catch (e) {
      debugPrint('refresh error: $e');
    } finally {
      if (mounted) setState(() => _loadingRefresh = false);
    }
  }

  bool _isOpenNow(String? opensAt, String? closesAt) {
    try {
      final now = DateTime.now();
      final p = (String? s) {
        if (s == null) return null;
        final parts = s.split(RegExp(r'[:.]'));
        if (parts.length < 2) return null;
        final h = int.tryParse(parts[0].trim()) ?? 0;
        final m = int.tryParse(parts[1].trim()) ?? 0;
        return DateTime(now.year, now.month, now.day, h, m);
      };
      final start = p(opensAt) ?? DateTime(now.year, now.month, now.day, 8, 0);
      final end = p(closesAt) ?? DateTime(now.year, now.month, now.day, 18, 0);
      if (end.isBefore(start)) {
        final endNext = end.add(const Duration(days: 1));
        return now.isAfter(start) || now.isBefore(endNext);
      }
      return now.isAfter(start.subtract(const Duration(minutes: 1))) && now.isBefore(end.add(const Duration(minutes: 1)));
    } catch (e) {
      return true;
    }
  }

  String _shortHours(String? opensAt, String? closesAt) {
    final o = opensAt ?? '--:--';
    final c = closesAt ?? '--:--';
    return '$o - $c';
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.colorScheme.primary, theme.colorScheme.primary.withOpacity(0.85)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 10, offset: const Offset(0, 6))],
            ),
            child: Center(
              child: Text('W', style: TextStyle(fontSize: 32, color: theme.colorScheme.primary)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Choose a canteen', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 6),
              Text('Fresh meals nearby — tap to browse menu', style: TextStyle(color: Colors.white.withOpacity(0.95))),
            ]),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _refresh,
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('canteens').snapshots();

    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(
        title: const Text('Select Canteen'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          const NotificationIcon(),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthUtils.logout(context),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildHeader(context),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _searchCtl,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Search by name or location',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  ),
                  onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () {
                  _searchCtl.clear();
                  setState(() => _query = '');
                },
                icon: const Icon(Icons.clear),
                label: const Text('Clear'),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14)),
              )
            ]),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: stream,
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final docs = snapshot.data!.docs;
                  final filtered = docs.where((d) {
                    final m = d.data();
                    final name = (m['name'] ?? '').toString().toLowerCase();
                    final loc = (m['location'] ?? '').toString().toLowerCase();
                    if (_query.isEmpty) return true;
                    return name.contains(_query) || loc.contains(_query);
                  }).toList();

                  if (filtered.isEmpty) {
                    return ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        const SizedBox(height: 80),
                        Icon(Icons.restaurant_menu, size: 56, color: Colors.grey.shade400),
                        const SizedBox(height: 12),
                        Center(child: Text('No canteens match "$_query"')),
                      ],
                    );
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final doc = filtered[index];
                      final data = doc.data();
                      final name = (data['name'] ?? 'Unnamed').toString();
                      final location = (data['location'] ?? 'Unknown location').toString();
                      final opensAt = data['opensAt']?.toString();
                      final closesAt = data['closesAt']?.toString();
                      final menu = data['menu'] is List ? List.from(data['menu']) : <dynamic>[];
                      final imgUrl = data['imageUrl'] as String?;
                      final isOpen = _isOpenNow(opensAt, closesAt);

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MenuScreen(
                                  canteenId: doc.id,
                                  canteenName: data['name'],
                                ),
                              ),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: isOpen
                                    ? [Colors.white, Colors.white]
                                    : [Colors.grey.shade100, Colors.grey.shade50],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 6))],
                              border: Border.all(color: Colors.grey.withOpacity(0.06)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 98,
                                  height: 98,
                                  margin: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    color: Colors.teal.shade50,
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: imgUrl != null && imgUrl.isNotEmpty
                                        ? Image.network(imgUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) {
                                            return Center(child: Text(name.substring(0, 1).toUpperCase(), style: TextStyle(fontSize: 28, color: Colors.teal.shade700)));
                                          })
                                        : Center(child: Text(name.substring(0, 1).toUpperCase(), style: TextStyle(fontSize: 28, color: Colors.teal.shade700))),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              child: Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                            ),
                                            const SizedBox(width: 6),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: isOpen ? Colors.green.shade600 : Colors.grey,
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Text(isOpen ? 'OPEN' : 'CLOSED', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Text(location, style: const TextStyle(color: Colors.black54)),
                                        const SizedBox(height: 8),
                                        Row(children: [
                                          Icon(Icons.schedule, size: 14, color: Colors.black54),
                                          const SizedBox(width: 6),
                                          Text(_shortHours(opensAt, closesAt), style: const TextStyle(color: Colors.black54, fontSize: 13)),
                                          const SizedBox(width: 12),
                                          Icon(Icons.menu_book, size: 14, color: Colors.black54),
                                          const SizedBox(width: 6),
                                          Text('${menu.length} items', style: const TextStyle(color: Colors.black54, fontSize: 13)),
                                        ]),
                                        const SizedBox(height: 8),
                                        Row(
                                          children: [
                                            ElevatedButton(
                                              onPressed: () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => MenuScreen(canteenId: doc.id, canteenName: data['name']),
                                                  ),
                                                );
                                              },
                                              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10)),
                                              child: const Text('View Menu'),
                                            ),
                                            const SizedBox(width: 8),
                                            OutlinedButton(
                                              onPressed: () {
                                              },
                                              child: const Text('Info'),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          )
        ],
      ),
    );
  }
}
