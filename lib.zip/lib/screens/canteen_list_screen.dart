import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'menu_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/utils/auth_utils.dart';
import 'package:canteen_app/widgets/notification_icon.dart';
import 'dart:async';
import 'package:intl/intl.dart'; 

class NotificationIcon extends StatelessWidget {
  const NotificationIcon({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();

    final notifQuery = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('notifications')
        .where('read', isEqualTo: false);

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: notifQuery.snapshots(),
      builder: (context, snap) {
        int unread = 0;
        if (snap.hasData) unread = snap.data!.docs.length;

        return Stack(
          alignment: Alignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_none),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const _InlineNotificationsScreen()),
                );
              },
            ),
            if (unread > 0)
              Positioned(
                right: 6,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  constraints: const BoxConstraints(minWidth: 20, minHeight: 18),
                  child: Text(
                    unread > 99 ? '99+' : '$unread',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _InlineNotificationsScreen extends StatefulWidget {
  const _InlineNotificationsScreen({super.key});
  @override
  State<_InlineNotificationsScreen> createState() => _InlineNotificationsScreenState();
}

class _InlineNotificationsScreenState extends State<_InlineNotificationsScreen> {
  Stream<QuerySnapshot<Map<String, dynamic>>>? _stream;

  @override
  void initState() {
    super.initState();
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      _stream = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('notifications')
          .orderBy('timestamp', descending: true)
          .snapshots();
    }
  }

  String _formatTimestamp(dynamic ts) {
    try {
      if (ts == null) return '';
      if (ts is Timestamp) {
        final dt = ts.toDate().toLocal();
        return DateFormat('dd MMM • hh:mm a').format(dt);
      }
      return ts.toString();
    } catch (_) {
      return '';
    }
  }

  Future<void> _markRead(DocumentReference<Map<String, dynamic>> ref) async {
    try {
      await ref.set({'read': true}, SetOptions(merge: true));
    } catch (e) {
      debugPrint('markRead error: $e');
    }
  }

  Future<void> _markAllRead(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) async {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in docs) {
      batch.set(d.reference, {'read': true}, SetOptions(merge: true));
    }
    try {
      await batch.commit();
    } catch (e) {
      debugPrint('markAllRead error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: const Center(child: Text('Please sign in')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snap) {
              if (!snap.hasData) return const SizedBox.shrink();
              final docs = snap.data!.docs;
              if (docs.isEmpty) return const SizedBox.shrink();
              return TextButton(
                onPressed: () => _markAllRead(docs),
                child: const Text('Mark all read', style: TextStyle(color: Colors.white)),
              );
            },
          )
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());

          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('No notifications yet'));

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final doc = docs[i];
              final data = doc.data();
              final title = (data['title'] ?? 'Notification').toString();
              final body = (data['body'] ?? '').toString();
              final ts = _formatTimestamp(data['timestamp']);
              final read = (data['read'] ?? false) == true;

              return ListTile(
                tileColor: read ? Colors.white : Colors.teal.shade50,
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 6),
                    Text(body),
                    const SizedBox(height: 6),
                    Text(ts, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  ],
                ),
                trailing: read
                    ? null
                    : TextButton(
                        onPressed: () async {
                          await _markRead(doc.reference);
                        },
                        child: const Text('Mark read'),
                      ),
                onTap: () async {
                  await _markRead(doc.reference);
                },
              );
            },
          );
        },
      ),
    );
  }
}

class CanteenListScreen extends StatelessWidget {
  const CanteenListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('canteens').snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Canteen'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        actions: [
          NotificationIcon(), // no const
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthUtils.logout(context),
          ),
        ],

      ),

      


      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('No canteens found.'));
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data();
              final name = data['name'] ?? 'Unnamed';
              final location = data['location'] ?? 'Unknown location';
              final opensAt = data['opensAt'] ?? '--:--';
              final closesAt = data['closesAt'] ?? '--:--';
              final menu = data['menu'] ?? [];

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                elevation: 3,
                child: ListTile(
                  leading: const Icon(Icons.restaurant_menu, size: 32),
                  title: Text(name,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 18)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(location),
                      Text('Opens: $opensAt, Closes: $closesAt'),
                      Text('Menu items: ${menu.length}'),
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MenuScreen(
                          canteenId: docs[index].id,
                          canteenName: data['name'],
                        ),
                      ),
                    );
                  },

                ),
              );
            },
          );
        },
      ),
    );
  }
}
