import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore_platform_interface/cloud_firestore_platform_interface.dart'; 
import 'package:firebase_auth/firebase_auth.dart';

class OrderDetailScreen extends StatefulWidget {
  final DocumentSnapshot<Map<String, dynamic>> orderDoc;
  const OrderDetailScreen({super.key, required this.orderDoc});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  late Map<String, dynamic> data;
  bool _updating = false;

  @override
  void initState() {
    super.initState();
    data = widget.orderDoc.data() ?? {};
  }

  Future<void> _updateStatus(String newStatus) async {
  setState(() => _updating = true);
  final docRef = FirebaseFirestore.instance.collection('orders').doc(widget.orderDoc.id);
  final adminUid = FirebaseAuth.instance.currentUser?.uid;

  try {
    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      if (!snap.exists) throw Exception('Order document not found');

      tx.update(docRef, {
        'status': newStatus,
        'lastUpdatedAt': FieldValue.serverTimestamp(),
        if (adminUid != null) 'lastUpdatedBy': adminUid,
      });
    });

    setState(() {
      data['status'] = newStatus;
      _updating = false;
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order status updated → $newStatus')));
    debugPrint('Order ${widget.orderDoc.id} updated to $newStatus by $adminUid');
  } on FirebaseException catch (fe) {
    setState(() => _updating = false);
    debugPrint('FirebaseException updating order: ${fe.code} ${fe.message}');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: ${fe.message}')));
    }
  } catch (e, st) {
    setState(() => _updating = false);
    debugPrint('Error updating order: $e\n$st');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
    }
  }
}


  @override
  Widget build(BuildContext context) {
    final idStr = data['orderIdString'] ?? widget.orderDoc.id;
    final canteenId = data['canteenId'] ?? '-';
    final userId = data['userId'] ?? '-';
    final total = (data['total'] as num?)?.toDouble() ?? 0.0;
    final paymentRef = data['payment']?['reference'] ?? '-';
    final createdAt = (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now();
    final items = (data['items'] as List<dynamic>?) ?? [];
    final status = data['status'] ?? 'placed';

    return Scaffold(
      appBar: AppBar(title: Text('Order: $idStr')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Canteen: $canteenId', style: const TextStyle(fontSize: 16)),
                Text(DateFormat('dd MMM, hh:mm a').format(createdAt), style: const TextStyle(color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 8),
            Text('User: $userId'),
            const SizedBox(height: 8),
            Text('Payment Ref: $paymentRef'),
            const SizedBox(height: 8),
            Text('Total: ₹${total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Status: ${status.toString().toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.teal)),
            const Divider(height: 24),
            const Text('Items:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            ...items.map((it) {
              final m = Map<String, dynamic>.from(it as Map);
              final price = (m['price'] as num?)?.toDouble() ?? 0.0;
              final qty = (m['qty'] as num?)?.toInt() ?? 0;
              return ListTile(
                dense: true,
                title: Text(m['name'] ?? ''),
                subtitle: Text('₹${price.toStringAsFixed(2)} × $qty = ₹${(price * qty).toStringAsFixed(2)}'),
              );
            }),

            const Divider(height: 24),
            const Text('Update Status', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),

            if (_updating)
              const Center(child: CircularProgressIndicator())
            else
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Select new status',
                ),
                items: const [
                  DropdownMenuItem(value: 'placed', child: Text('Placed')),
                  DropdownMenuItem(value: 'confirmed', child: Text('Confirmed')),
                  DropdownMenuItem(value: 'preparing', child: Text('Preparing')),
                  DropdownMenuItem(value: 'completed', child: Text('Completed')),
                  DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
                ],
                onChanged: (val) {
                  if (val != null && val != status) _updateStatus(val);
                },
              ),

            const SizedBox(height: 20),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.check_circle_outline),
                  label: const Text('Confirm'),
                  onPressed: status != 'confirmed' ? () => _updateStatus('confirmed') : null,
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.local_dining_outlined),
                  label: const Text('Preparing'),
                  onPressed: status != 'preparing' ? () => _updateStatus('preparing') : null,
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.done_all),
                  label: const Text('Complete'),
                  onPressed: status != 'completed' ? () => _updateStatus('completed') : null,
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.cancel_outlined),
                  label: const Text('Cancel'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  onPressed: status != 'cancelled' ? () => _updateStatus('cancelled') : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
