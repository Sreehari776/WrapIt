import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  String _formatTimestamp(dynamic ts) {
    try {
      if (ts == null) return '';
      if (ts is Timestamp) {
        return DateFormat('dd MMM yyyy • hh:mm a').format(ts.toDate().toLocal());
      }
      if (ts is Map && (ts.containsKey('_seconds') || ts.containsKey('seconds'))) {
        final seconds = (ts['_seconds'] ?? ts['seconds']) as int;
        final dt = DateTime.fromMillisecondsSinceEpoch(seconds * 1000).toLocal();
        return DateFormat('dd MMM yyyy • hh:mm a').format(dt);
      }
      if (ts is DateTime) {
        return DateFormat('dd MMM yyyy • hh:mm a').format(ts.toLocal());
      }
      return ts.toString();
    } catch (_) {
      return ts?.toString() ?? '';
    }
  }

  double _parseTotal(dynamic raw) {
    try {
      if (raw == null) return 0.0;
      if (raw is num) return raw.toDouble();
      return double.tryParse(raw.toString()) ?? 0.0;
    } catch (_) {
      return 0.0;
    }
  }

  Color _statusColor(String status) {
    final s = status.toLowerCase();
    if (s.contains('completed') || s.contains('complete')) return Colors.green.shade700;
    if (s.contains('cancel')) return Colors.red.shade700;
    if (s.contains('preparing') || s.contains('confirmed')) return Colors.orange.shade700;
    if (s.contains('placed') || s.contains('pending')) return Colors.blueGrey.shade700;
    return Colors.blueGrey;
  }

  IconData _statusIcon(String status) {
    final s = status.toLowerCase();
    if (s.contains('completed') || s.contains('complete')) return Icons.check_circle_outline;
    if (s.contains('cancel')) return Icons.cancel_outlined;
    if (s.contains('preparing')) return Icons.local_dining_outlined;
    if (s.contains('confirmed')) return Icons.verified_outlined;
    return Icons.schedule;
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please log in to view your orders.')),
      );
    }

    final orderStream = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('orders')
        .orderBy('placedAt', descending: true)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Orders'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.teal,
        elevation: 2,
        centerTitle: true,
      ),
      backgroundColor: Colors.grey.shade50,
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: orderStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            final fallback = FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .collection('orders')
                .orderBy('timestamp', descending: true)
                .snapshots();
            return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: fallback,
              builder: (ctx, snap2) {
                if (snap2.hasError) return Center(child: Text('Error: ${snap2.error}'));
                if (!snap2.hasData) return const Center(child: CircularProgressIndicator());
                return _buildList(context, snap2.data!.docs);
              },
            );
          }

          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final orders = snapshot.data!.docs;
          if (orders.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.history_toggle_off, size: 68, color: Colors.teal.shade200),
                  const SizedBox(height: 12),
                  Text('No orders yet', style: TextStyle(fontSize: 18, color: Colors.grey.shade700)),
                  const SizedBox(height: 6),
                  Text('Your recent orders will appear here.', style: TextStyle(color: Colors.grey.shade500)),
                ],
              ),
            );
          }

          return _buildList(context, orders);
        },
      ),
    );
  }

  Widget _buildList(BuildContext context, List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    final currency = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      itemCount: docs.length,
      itemBuilder: (context, index) {
        final doc = docs[index];
        final order = doc.data();

        final orderNo = (order['orderNumber'] ?? order['orderId'] ?? doc.id).toString();
        final total = _parseTotal(order['total'] ?? order['amount'] ?? order['price']);
        final status = (order['status'] ?? 'Unknown').toString();
        final refId = (order['paymentRefId'] ?? order['paymentRef'] ?? 'Not Provided').toString();
        final canteen = (order['canteen'] ?? order['canteenName'] ?? '').toString();

        dynamic ts = order['placedAt'] ?? order['timestamp'] ?? order['createdAt'];
        String placedAtStr = '';
        if (ts != null) {
          placedAtStr = _formatTimestamp(ts);
        }

        String? prebookTime;
        try {
          final pb = order['prebookAt'] ?? order['prebookTime'];
          if (pb != null) {
            if (pb is Timestamp) {
              prebookTime = DateFormat('hh:mm a').format(pb.toDate().toLocal());
            } else if (pb is String) {
              final parsed = DateTime.tryParse(pb);
              if (parsed != null) prebookTime = DateFormat('hh:mm a').format(parsed.toLocal());
            } else if (pb is Map && (pb['seconds'] != null || pb['_seconds'] != null)) {
              final seconds = (pb['seconds'] ?? pb['_seconds']) as int;
              prebookTime = DateFormat('hh:mm a').format(DateTime.fromMillisecondsSinceEpoch(seconds * 1000).toLocal());
            }
          }
        } catch (_) {
          prebookTime = null;
        }

        final itemsList = <dynamic>[];
        try {
          final rawItems = order['items'];
          if (rawItems is List) itemsList.addAll(rawItems);
        } catch (_) {}

        final statusColor = _statusColor(status);
        final statusIcon = _statusIcon(status);

        return Card(
          elevation: 3,
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // header row - made robust to long text
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // leading icon
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: statusColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(statusIcon, color: statusColor, size: 22),
                    ),
                    const SizedBox(width: 12),

                    // order info (constrained)
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // order number - single-line ellipsis
                          Text(
                            'Order #$orderNo',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(children: [
                            if (placedAtStr.isNotEmpty)
                              Flexible(
                                child: Text(
                                  placedAtStr,
                                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            if (placedAtStr.isNotEmpty && canteen.isNotEmpty) const SizedBox(width: 8),
                            if (canteen.isNotEmpty)
                              Flexible(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade100,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    canteen,
                                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                          ]),
                        ],
                      ),
                    ),

                    const SizedBox(width: 8),

                    // status chip (constrained so it won't push layout)
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 140),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Chip(
                            backgroundColor: statusColor.withOpacity(0.14),
                            avatar: CircleAvatar(
                              radius: 10,
                              backgroundColor: statusColor,
                              child: Icon(statusIcon, size: 14, color: Colors.white),
                            ),
                            label: Text(
                              status,
                              style: TextStyle(color: statusColor, fontWeight: FontWeight.w600),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                            visualDensity: VisualDensity.compact,
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                          ),
                          const SizedBox(height: 6),
                          Text(currency.format(total), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // payment / prebook row - make left part flexible
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Payment Ref: ${refId.isEmpty ? "—" : refId}',
                        style: const TextStyle(color: Colors.black87),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (prebookTime != null) ...[
                      const SizedBox(width: 8),
                      Text('Pickup: $prebookTime', style: const TextStyle(color: Colors.black54)),
                    ],
                  ],
                ),

                const Divider(height: 20),

                // items expansion
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  childrenPadding: const EdgeInsets.only(left: 4, right: 4, bottom: 6),
                  title: Text('Items (${itemsList.length})', style: const TextStyle(fontWeight: FontWeight.w600)),
                  children: itemsList.isEmpty
                      ? [const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('- No items recorded -'))]
                      : itemsList.map((item) {
                          try {
                            final name = (item['name'] ?? item['title'] ?? item['itemName'] ?? '').toString();
                            final rawQty = item['qty'] ?? item['quantity'] ?? item['count'] ?? 1;
                            final qty = (rawQty is num) ? rawQty.toInt() : (int.tryParse(rawQty.toString()) ?? 1);
                            final price = (item['price'] ?? item['amount'] ?? 0);
                            final priceValue = (price is num) ? price.toDouble() : double.tryParse('$price') ?? 0.0;
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Row(
                                children: [
                                  Expanded(child: Text(name, style: const TextStyle(fontSize: 14), overflow: TextOverflow.ellipsis)),
                                  Text('x$qty', style: const TextStyle(color: Colors.black54)),
                                  const SizedBox(width: 12),
                                  Text(currency.format(priceValue), style: const TextStyle(fontWeight: FontWeight.w600)),
                                ],
                              ),
                            );
                          } catch (_) {
                            return const Padding(
                              padding: EdgeInsets.symmetric(vertical: 6),
                              child: Text('• Unknown item'),
                            );
                          }
                        }).toList(),
                ),

                // optional footer actions
                const SizedBox(height: 8),
                Row(
                  children: [
                    // keep details button but make it shrinkable
                    Flexible(
                      fit: FlexFit.loose,
                      child: TextButton.icon(
                        onPressed: () {
                          // preserved placeholder; navigate to detail if available
                          // Navigator.push(context, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderDoc: doc)));
                        },
                        icon: const Icon(Icons.info_outline, size: 18),
                        label: const Text('Details'),
                        style: TextButton.styleFrom(foregroundColor: Colors.teal.shade700),
                      ),
                    ),
                    const Spacer(),
                    // make order id small and allow ellipsis if long
                    Flexible(
                      child: Text(
                        'Order ID: ${doc.id}',
                        style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
