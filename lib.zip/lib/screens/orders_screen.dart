import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  String _formatTimestamp(dynamic ts) {
    try {
      if (ts == null) return '';
      if (ts is Timestamp) {
        return DateFormat('dd MMM yyyy • hh:mm a').format(ts.toDate().toLocal());
      }
      if (ts is Map && (ts.containsKey('_seconds') || ts.containsKey('seconds'))) {
        final seconds = (ts['_seconds'] ?? ts['seconds']) as int;
        final dt = DateTime.fromMillisecondsSinceEpoch(seconds * 1000).toLocal();
        return DateFormat('dd MMM yyyy • hh:mm a').format(dt);
      }
      if (ts is DateTime) {
        return DateFormat('dd MMM yyyy • hh:mm a').format(ts.toLocal());
      }
      return ts.toString();
    } catch (_) {
      return ts?.toString() ?? '';
    }
  }

  double _parseTotal(dynamic raw) {
    try {
      if (raw == null) return 0.0;
      if (raw is num) return raw.toDouble();
      return double.tryParse(raw.toString()) ?? 0.0;
    } catch (_) {
      return 0.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please log in to view your orders.')),
      );
    }

    final orderStream = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('orders')
        .orderBy('placedAt', descending: true) // preferred
        .snapshots()
        ;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Orders'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: orderStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            final fallback = FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .collection('orders')
                .orderBy('timestamp', descending: true)
                .snapshots();
            return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: fallback,
              builder: (ctx, snap2) {
                if (snap2.hasError) return Center(child: Text('Error: ${snap2.error}'));
                if (!snap2.hasData) return const Center(child: CircularProgressIndicator());
                return _buildList(context, snap2.data!.docs);
              },
            );
          }

          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final orders = snapshot.data!.docs;
          if (orders.isEmpty) return const Center(child: Text('No orders yet.'));

          return _buildList(context, orders);
        },
      ),
    );
  }

  Widget _buildList(BuildContext context, List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: docs.length,
      itemBuilder: (context, index) {
        final doc = docs[index];
        final order = doc.data();

        final orderNo = (order['orderNumber'] ?? order['orderId'] ?? doc.id).toString();
        final total = _parseTotal(order['total'] ?? order['amount'] ?? order['price']);
        final status = (order['status'] ?? 'Unknown').toString();
        final refId = (order['paymentRefId'] ?? order['paymentRef'] ?? 'Not Provided').toString();
        final canteen = (order['canteen'] ?? order['canteenName'] ?? '').toString();

        dynamic ts = order['placedAt'] ?? order['timestamp'] ?? order['createdAt'];
        String placedAtStr = '';
        if (ts != null) {
          placedAtStr = _formatTimestamp(ts);
        }
        String? prebookTime;
        try {
          final pb = order['prebookTime'];
          if (pb != null) {
            if (pb is Timestamp) {
              prebookTime = DateFormat('hh:mm a').format(pb.toDate().toLocal());
            } else if (pb is String) {
              final parsed = DateTime.tryParse(pb);
              if (parsed != null) prebookTime = DateFormat('hh:mm a').format(parsed.toLocal());
            } else if (pb is Map && (pb['seconds'] != null || pb['_seconds'] != null)) {
              final seconds = (pb['seconds'] ?? pb['_seconds']) as int;
              prebookTime = DateFormat('hh:mm a').format(DateTime.fromMillisecondsSinceEpoch(seconds * 1000).toLocal());
            }
          }
        } catch (_) {
          prebookTime = null;
        }

        final itemsList = <dynamic>[];
        try {
          final rawItems = order['items'];
          if (rawItems is List) itemsList.addAll(rawItems);
        } catch (_) {}

        return Card(
          elevation: 3,
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Order #$orderNo',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.teal),
                  ),
                  if (placedAtStr.isNotEmpty) Text(placedAtStr, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
              const SizedBox(height: 8),
              Text('Canteen: ${canteen.isEmpty ? "—" : canteen}', style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 4),
              Text('Total: ₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 4),
              Text(
                'Status: $status',
                style: TextStyle(
                  fontSize: 16,
                  color: status.toLowerCase() == 'completed'
                      ? Colors.green
                      : (status.toLowerCase() == 'pending' ? Colors.orange : Colors.blueGrey),
                ),
              ),
              if (prebookTime != null) ...[
                const SizedBox(height: 4),
                Text('Prebooked for: $prebookTime', style: const TextStyle(fontSize: 15)),
              ],
              const SizedBox(height: 6),
              Text('Payment Ref ID: $refId', style: const TextStyle(fontSize: 15)),
              const Divider(height: 20),
              const Text('Items:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black54)),
              const SizedBox(height: 6),
              if (itemsList.isEmpty)
                const Text('- No items recorded -', style: TextStyle(fontSize: 14))
              else
                ...itemsList.map((item) {
                  try {
                    final name = (item['name'] ?? item['title'] ?? item['itemName'] ?? '').toString();
                    final rawQty = item['qty'] ?? item['quantity'] ?? item['count'] ?? 1;
                    final qty = (rawQty is num) ? rawQty.toInt() : (int.tryParse(rawQty.toString()) ?? 1);
                    final price = (item['price'] ?? item['amount'] ?? 0);
                    final priceValue = (price is num) ? price.toDouble() : double.tryParse('$price') ?? 0.0;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4.0),
                      child: Text('• $name × $qty  —  ₹${priceValue.toStringAsFixed(0)}', style: const TextStyle(fontSize: 14)),
                    );
                  } catch (_) {
                    return const Text('• Unknown item', style: TextStyle(fontSize: 14));
                  }
                }).toList(),
            ]),
          ),
        );
      },
    );
  }
}
