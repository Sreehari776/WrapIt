import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'firebase_options.dart';
import 'screens/sign_in_screen.dart';
import 'screens/canteen_list_screen.dart';
import 'screens/select_canteen_screen.dart';
import 'admin/admin_dashboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // --- Helper that decides which screen to show for each role
  Widget _widgetForRole(String? role) {
    switch (role) {
      case 'admin':
        return const AdminDashboard();
      case 'pending_admin':
        return const SelectCanteenScreen();
      default:
        return const CanteenListScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Canteen App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, authSnap) {
          // Wait for Firebase Auth to initialize
          if (authSnap.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          final user = authSnap.data;

          // --- If not signed in, go to Sign In
          if (user == null) {
            return const SignInScreen();
          }

          // --- If signed in, listen to the user's Firestore doc for role updates
          final userDocStream = FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .snapshots();

          return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: userDocStream,
            builder: (context, docSnap) {
              if (docSnap.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }

              if (docSnap.hasError) {
                debugPrint(
                    'Error reading user doc for ${user.uid}: ${docSnap.error}');
                return const CanteenListScreen();
              }

              final doc = docSnap.data;                 // DocumentSnapshot<Map<String,dynamic>>? (nullable)
              final data = doc?.data();                // Map<String,dynamic>? (nullable)

             final role = data == null
                ? 'user'
              : (data['role'] ?? 'user') as String;

return _widgetForRole(role);
            },
          );
        },
      ),
    );
  }
}
