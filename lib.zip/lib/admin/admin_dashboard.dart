import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:canteen_app/utils/auth_utils.dart';
import 'admin_orders_screen.dart';
import '../screens/select_canteen_screen.dart';
import 'admin_orders_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  bool _loading = false;

  Future<void> _openOrders() async {
    setState(() => _loading = true);
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Not signed in')));
        return;
      }

      final udoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final canteenId = udoc.data()?['canteenId'];

      if (canteenId == null) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No canteen assigned. Please select a canteen.')));
        return;
      }

      if (mounted) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => AdminOrdersScreen(),
    ),
  );
}

    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to open orders: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
  Future<void> _switchCanteen(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .set({'canteenId': FieldValue.delete()}, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Failed to clear canteenId: $e');
    }

    if (!context.mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const SelectCanteenScreen()),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.red),
            tooltip: 'Logout',
            onPressed: () => AuthUtils.logout(context),
          ),
          IconButton(
            icon: const Icon(Icons.swap_horiz, color: Colors.blueGrey),
            tooltip: 'Switch Canteen',
            onPressed: () => _switchCanteen(context),
),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Welcome, Admin!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            ElevatedButton.icon(
              icon: const Icon(Icons.list),
              label: const Text('View Orders'),
              onPressed: _loading ? null : _openOrders,
            ),

            const SizedBox(height: 12),
            
            if (_loading) const Padding(
              padding: EdgeInsets.only(top: 8.0),
              child: CircularProgressIndicator(),
            ),
          ],
        ),
      ),
    );
  }
}
