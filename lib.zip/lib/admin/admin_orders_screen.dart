// lib/admin/admin_orders_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:canteen_app/utils/auth_utils.dart';
import 'package:flutter/services.dart';

class AdminOrdersScreen extends StatefulWidget {
  final String canteenId;
  const AdminOrdersScreen({super.key, required this.canteenId});

  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  String _selectedStatus = 'All';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  Stream<QuerySnapshot<Map<String, dynamic>>> _ordersStream() {
    return FirebaseFirestore.instance
        .collection('canteens')
        .doc(widget.canteenId)
        .collection('orders')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  Color _statusColor(String status) {
    final s = status.toLowerCase();
    if (s == 'completed') return Colors.green;
    if (s == 'preparing' || s == 'processing') return Colors.orange;
    return Colors.blueGrey;
  }

  String _formatTimestamp(dynamic ts) {
    try {
      if (ts == null) return '';
      if (ts is Timestamp) {
        final dt = ts.toDate().toLocal();
        return DateFormat('dd MMM • hh:mm a').format(dt);
      }
      return ts.toString();
    } catch (_) {
      return '';
    }
  }

  double _computeSubtotal(List<dynamic> items) {
    double total = 0.0;
    for (var it in items) {
      if (it == null) continue;
      final priceRaw = it['price'] ?? 0;
      final qtyRaw = it['qty'] ?? it['quantity'] ?? it['count'] ?? 1;
      final price = (priceRaw is num) ? priceRaw.toDouble() : double.tryParse('$priceRaw') ?? 0.0;
      final qty = (qtyRaw is num) ? qtyRaw.toDouble() : double.tryParse('$qtyRaw') ?? 1.0;
      total += price * qty;
    }
    return total;
  }

  // used to compute today's sales from the current snapshot (client-side)
  bool _isSameDay(Timestamp? ts) {
    if (ts == null) return false;
    final dt = ts.toDate().toLocal();
    final now = DateTime.now();
    return dt.year == now.year && dt.month == now.month && dt.day == now.day;
  }

Future<void> _updateStatus(String orderId, String newStatus, String? userId) async {
  try {
    final canteenOrderDocRef = FirebaseFirestore.instance
        .collection('canteens')
        .doc(widget.canteenId)
        .collection('orders')
        .doc(orderId);

    // Read the order doc so we can pick a friendly orderNumber if it exists
    final canteenOrderSnap = await canteenOrderDocRef.get();
    final canteenOrderData = canteenOrderSnap.data() ?? <String, dynamic>{};

    // Prefer a human-friendly order number if available, otherwise use the doc id
    final friendlyOrderNumber = (canteenOrderData['orderNumber'] != null && (canteenOrderData['orderNumber'] as String).isNotEmpty)
        ? canteenOrderData['orderNumber'].toString()
        : orderId;

    final batch = FirebaseFirestore.instance.batch();

    // Update status in canteen orders
    batch.update(canteenOrderDocRef, {'status': newStatus});

    // If we have a userId, update their order doc and also create a notification
    if (userId != null && userId.isNotEmpty) {
      final userOrderDocRef = FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('orders')
          .doc(orderId);

      batch.set(userOrderDocRef, {'status': newStatus}, SetOptions(merge: true));

      // Build a proper Map<String, dynamic> for the notification
      final Map<String, dynamic> notifData = {
        'title': 'Order Update',
        // use friendlyOrderNumber (e.g. ORD-S-0001) if present, otherwise the orderId
        'body': 'Your order $orderId has been marked as $newStatus.',
        'orderId': orderId,
        'orderNumber': friendlyOrderNumber,
        'status': newStatus,
        'timestamp': FieldValue.serverTimestamp(),
        'read': false,
      };

      final notifRef = FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('notifications')
          .doc();

      batch.set(notifRef, notifData);
    }

    // Commit all changes atomically
    await batch.commit();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Order $orderId set to $newStatus')),
    );
  } on FirebaseException catch (e) {
    debugPrint('updateStatus FirebaseException: ${e.code} ${e.message}');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Failed to update order: ${e.code}')),
    );
  } catch (e) {
    debugPrint('updateStatus error: $e');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Failed to update order')),
    );
  }
}



  Widget _statusChip(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: _statusColor(status).withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        status,
        style: TextStyle(color: _statusColor(status), fontWeight: FontWeight.bold),
      ),
    );
  }

  void _setFilter(String status) {
    setState(() {
      _selectedStatus = status;
    });
  }

  void _onSearchChanged(String q) {
    setState(() {
      _searchQuery = q.trim().toLowerCase();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // helper: whether a doc matches current filters/search
  bool _docMatchesFilters(Map<String, dynamic> data) {
    final status = (data['status'] ?? 'Pending').toString();
    if (_selectedStatus != 'All' && status.toLowerCase() != _selectedStatus.toLowerCase()) {
      return false;
    }
    if (_searchQuery.isEmpty) return true;

    final orderNumber = (data['orderNumber'] ?? '').toString().toLowerCase();
    final orderId = (data['orderId'] ?? '').toString().toLowerCase();
    final paymentRef = (data['paymentRefId'] ?? data['paymentRef'] ?? '').toString().toLowerCase();

    return orderNumber.contains(_searchQuery) || orderId.contains(_searchQuery) || paymentRef.contains(_searchQuery);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Canteen Orders'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.red),
            onPressed: () => AuthUtils.logout(context),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ordersStream(),
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());

          final docs = snap.data!.docs;

          // compute today's sales from the snapshot (client-side)
          double todaysSales = 0.0;
          for (var d in docs) {
            final data = d.data();
            if (_isSameDay(data['timestamp'])) {
              final items = (data['items'] as List<dynamic>?) ?? [];
              todaysSales += _computeSubtotal(items);
            }
          }

          // filtered list (in memory) - we do client-side filtering for speed of UI changes
          final filtered = docs.where((d) => _docMatchesFilters(d.data())).toList();

          return Column(
            children: [
              // Top controls: status filters, search, today's sales
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 10),
                child: Column(
                  children: [
                    Row(
                      children: [
                        // Status filter chips
                        _buildFilterChip('All'),
                        const SizedBox(width: 6),
                        _buildFilterChip('Pending'),
                        const SizedBox(width: 6),
                        _buildFilterChip('Preparing'),
                        const SizedBox(width: 6),
                        _buildFilterChip('Completed'),
                        const Spacer(),
                        // Today's sales badge
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('Today\'s Sales', style: TextStyle(fontSize: 12, color: Colors.black54)),
                            const SizedBox(height: 4),
                            Text('₹${todaysSales.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    // Search field (order number / id / payment ref)
                    TextField(
                      controller: _searchController,
                      onChanged: _onSearchChanged,
                      decoration: InputDecoration(
                        hintText: 'Search order number / id / payment ref',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _searchController.clear();
                                  _onSearchChanged('');
                                },
                              )
                            : null,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                      ),
                    ),
                  ],
                ),
              ),

              const Divider(height: 8),

              // Order list
              Expanded(
                child: filtered.isEmpty
                    ? const Center(child: Text('No orders match the filter'))
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, i) {
                          final doc = filtered[i];
                          final data = doc.data();

                          final orderId = data['orderId'] ?? doc.id;
                          final orderNumber = data['orderNumber'] ?? orderId;
                          final paymentRef = data['paymentRefId'] ?? data['paymentRef'] ?? 'N/A';
                          final status = (data['status'] ?? 'Pending').toString();
                          final items = (data['items'] as List<dynamic>?) ?? [];
                          final subtotal = _computeSubtotal(items);
                          final tsText = _formatTimestamp(data['timestamp']);
                          final userId = data['userId'] != null ? data['userId'].toString() : null;

                          return Card(
                            elevation: 3,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(orderNumber, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                    ),
                                    const SizedBox(width: 8),
                                    _statusChip(status),
                                    const SizedBox(width: 8),
                                    Flexible(
                                      child: Text(tsText, style: const TextStyle(fontSize: 12, color: Colors.black54), overflow: TextOverflow.ellipsis),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 8),

                                Row(
                                  children: [
                                    Expanded(child: Text('Payment Ref: $paymentRef', style: const TextStyle(fontSize: 13))),
                                    Text('Subtotal: ₹${subtotal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                                  ],
                                ),

                                const SizedBox(height: 8),

                                ExpansionTile(
                                  tilePadding: EdgeInsets.zero,
                                  title: const Text('Items', style: TextStyle(fontWeight: FontWeight.w600)),
                                  children: [
                                    ...items.map((it) {
                                      final name = it['name'] ?? 'Item';
                                      final rawQty = it['qty'] ?? it['quantity'] ?? it['count'] ?? 1;
                                      final qty = (rawQty is num) ? rawQty.toInt() : (int.tryParse('$rawQty') ?? 1);
                                      final priceRaw = it['price'] ?? 0;
                                      final price = (priceRaw is num) ? priceRaw.toDouble() : double.tryParse('$priceRaw') ?? 0.0;
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 6),
                                        child: Row(
                                          children: [
                                            Expanded(child: Text(name)),
                                            Text('× $qty'),
                                            const SizedBox(width: 12),
                                            Text('₹${(price * qty).toStringAsFixed(2)}'),
                                          ],
                                        ),
                                      );
                                    }).toList(),
                                  ],
                                ),

                                const SizedBox(height: 6),

                                Row(
                                  children: [
                                    ElevatedButton(
                                      onPressed: status.toLowerCase() == 'preparing' || status.toLowerCase() == 'completed'
                                          ? null
                                          : () => _updateStatus(orderId, 'Preparing', userId),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.orange,
                                        minimumSize: const Size(140, 40),
                                      ),
                                      child: const Text('Mark Preparing'),
                                    ),
                                    const SizedBox(width: 8),
                                    ElevatedButton(
                                      onPressed: status.toLowerCase() == 'completed'
                                          ? null
                                          : () => _updateStatus(orderId, 'Completed', userId),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        minimumSize: const Size(140, 40),
                                      ),
                                      child: const Text('Mark Completed'),
                                    ),
                                    const SizedBox(width: 8),
                                    IconButton(
                                      tooltip: 'Copy order id',
                                      icon: const Icon(Icons.copy, size: 20),
                                      onPressed: () {
                                        Clipboard.setData(ClipboardData(text: orderId));
                                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order ID copied')));
                                      },
                                    ),
                                  ],
                                ),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  // small helper to build a filter chip and show selection
  Widget _buildFilterChip(String label) {
    final active = _selectedStatus.toLowerCase() == label.toLowerCase();
    return ChoiceChip(
      label: Text(label),
      selected: active,
      onSelected: (_) => _setFilter(label),
      selectedColor: Colors.teal.shade100,
    );
  }
}
