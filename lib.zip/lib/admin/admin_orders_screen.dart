import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import '../screens/order_tracking.dart';
import 'package:intl/intl.dart';

class AdminOrdersScreen extends StatefulWidget {
  const AdminOrdersScreen({super.key});
  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  final TextEditingController _searchCtl = TextEditingController();
  String _sort = 'newest';
  String _clientFilter = '';

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  Query<Map<String, dynamic>> _buildQuery(FirebaseFirestore fs) {
    var q = fs.collectionGroup('orders').withConverter<Map<String,dynamic>>(
      fromFirestore: (snap, _) => snap.data() ?? <String,dynamic>{},
      toFirestore: (m, _) => m,
    );

    if (_sort == 'newest') {
      q = q.orderBy('createdAt', descending: true);
    } else if (_sort == 'oldest') {
      q = q.orderBy('createdAt', descending: false);
    } else if (_sort == 'status') {
      q = q.orderBy('status').orderBy('createdAt', descending: true);
    }
    return q;
  }

  Future<void> _handleFirebaseException(BuildContext ctx, FirebaseException e) async {
    final msg = e.message ?? e.toString();
    final regex = RegExp(r'https?://[^ \n]+');
    final match = regex.firstMatch(msg);
    final url = match?.group(0);
    if (url != null) {
      final open = await showDialog<bool>(
        context: ctx,
        builder: (c) => AlertDialog(
          title: const Text('Index required'),
          content: SelectableText('Firestore requires a composite index for this query.\n\nTap "Open" to create the index in Firebase Console.\n\nURL:\n$url'),
          actions: [
            TextButton(onPressed: () => Navigator.of(c).pop(false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.of(c).pop(true), child: const Text('Open')),
          ],
        ),
      );
      if (open == true) {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        } else {
          ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Cannot open browser')));
        }
      }
    } else {
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Firestore error: ${e.code}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final fs = FirebaseFirestore.instance;
    final query = _buildQuery(fs);

    return Scaffold(
      appBar: AppBar(title: const Text('Admin — Orders')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _searchCtl,
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search order id (exact) or customer id'),
                  onChanged: (v) => setState(() => _clientFilter = v.trim().toLowerCase()),
                  onSubmitted: (v) {
                    final val = v.trim();
                    if (val.isNotEmpty) _searchExactOrder(val);
                  },
                ),
              ),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: _sort,
                items: const [
                  DropdownMenuItem(value: 'newest', child: Text('Newest')),
                  DropdownMenuItem(value: 'oldest', child: Text('Oldest')),
                  DropdownMenuItem(value: 'status', child: Text('By status')),
                ],
                onChanged: (s) => setState(() => _sort = s ?? 'newest'),
              ),
              const SizedBox(width: 8),
              IconButton(
                tooltip: 'Refresh',
                icon: const Icon(Icons.refresh),
                onPressed: () => setState(() {}),
              )
            ]),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: query.snapshots(),
              builder: (context, snap) {
                if (snap.hasError) {
                  final e = snap.error;
                  if (e is FirebaseException) {
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      _handleFirebaseException(context, e);
                    });
                  }
                  return Center(child: Text('Error: ${snap.error}'));
                }
                if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                final docs = snap.data?.docs ?? [];

                final filtered = _clientFilter.isEmpty
                    ? docs
                    : docs.where((d) {
                        final data = d.data();
                        final idStr = (data['orderIdString'] as String?) ?? d.id;
                        final user = (data['userId'] as String?) ?? '';
                        return idStr.toLowerCase().contains(_clientFilter) || user.toLowerCase().contains(_clientFilter);
                      }).toList();

                if (filtered.isEmpty) return const Center(child: Text('No orders'));

                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final doc = filtered[i];
                    final data = doc.data();
                    final idStr = (data['orderIdString'] as String?) ?? doc.id;
                    final total = (data['total'] as num?)?.toDouble() ?? 0.0;
                    final status = data['status'] ?? 'placed';
                    final created = (data['createdAt'] as Timestamp?)?.toDate();

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Material(
                        color: Colors.white,
                        elevation: 1,
                        borderRadius: BorderRadius.circular(8),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () {
                            debugPrint('Admin tapped order: ${doc.id}');
                            try {
                              Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => OrderTrackingScreen(orderDoc: doc)));
                            } catch (e, st) {
                              debugPrint('NAVIGATION ERROR: $e\n$st');
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Navigation failed: $e')));
                            }
                          },
                          child: ListTile(
                            title: Text(idStr),
                            subtitle: Text('₹${total.toStringAsFixed(2)} • ${data['canteenId'] ?? '-'} • ${status.toString()}'),
                            trailing: created == null ? null : Text(DateFormat('hh:mm a').format(created)),
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _searchExactOrder(String val) async {
    final fs = FirebaseFirestore.instance;
    try {
      final snap = await fs.collectionGroup('orders').where('orderIdString', isEqualTo: val).limit(1).get();
      if (snap.docs.isNotEmpty) {
        final doc = snap.docs.first;
        if (!mounted) return;
        Navigator.push(context, MaterialPageRoute(builder: (_) => OrderTrackingScreen(orderDoc: doc)));
        return;
      }

      final docRef = fs.collection('orders').doc(val);
      final docSnap = await docRef.get();
      if (docSnap.exists) {
        if (!mounted) return;
        Navigator.push(context, MaterialPageRoute(builder: (_) => OrderTrackingScreen(orderDoc: docSnap)));
        return;
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No exact order found')));
    } on FirebaseException catch (e) {
      await _handleFirebaseException(context, e);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Search failed: $e')));
    }
  }
}
